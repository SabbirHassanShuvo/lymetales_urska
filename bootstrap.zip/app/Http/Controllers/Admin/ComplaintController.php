<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Complaint;
use Illuminate\Http\Request;

class ComplaintController extends Controller
{
    public function index()
    {
        $complaints = Complaint::with(['user', 'targetUser'])->latest()->get();
        return view('admin.complaints.index', compact('complaints'));
    }

    public function show($id)
    {
        $complaint = Complaint::with(['user', 'targetUser'])->findOrFail($id);
        return view('admin.complaints.show', compact('complaint'));
    }

    public function updateStatus(Request $request, $id)
    {
        $complaint = Complaint::findOrFail($id);
        $complaint->update(['status' => $request->status]);

        return back()->with('success', 'Status updated successfully.');
    }

    public function destroy($id)
    {
        Complaint::findOrFail($id)->delete();
        return back()->with('success', 'Entry deleted successfully.');
    }
}
