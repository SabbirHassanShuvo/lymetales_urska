<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ContactCategory;
use App\Models\ContactItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ContactController extends Controller
{
    public function index()
    {
        $categories = ContactCategory::withCount('items')->get();
        return view('admin.contacts.index', compact('categories'));
    }

    public function storeCategory(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'icon' => 'nullable|string',
        ]);

        ContactCategory::create($request->all());

        return back()->with('success', 'Contact Category created successfully.');
    }

    public function updateCategory(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $category = ContactCategory::findOrFail($id);
        $category->update($request->all());

        return back()->with('success', 'Category updated successfully.');
    }

    public function show($id)
    {
        $category = ContactCategory::with('items')->findOrFail($id);
        return view('admin.contacts.show', compact('category'));
    }

    public function storeItem(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'phone' => 'required|string|max:255',
        ]);

        $category = ContactCategory::findOrFail($id);

        ContactItem::create([
            'contact_category_id' => $category->id,
            'title' => $request->title,
            'type' => 'phone',
            'content' => $request->phone,
        ]);

        return back()->with('success', 'Contact added successfully.');
    }

    public function updateItem(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'phone' => 'required|string|max:255',
        ]);

        $item = ContactItem::findOrFail($id);
        $item->update([
            'title' => $request->title,
            'content' => $request->phone,
        ]);

        return back()->with('success', 'Contact updated successfully.');
    }

    public function destroyItem($id)
    {
        $item = ContactItem::findOrFail($id);
        if ($item->type === 'file') {
            Storage::disk('public')->delete($item->content);
        }
        $item->delete();

        return back()->with('success', 'Contact deleted successfully.');
    }

    public function destroyCategory($id)
    {
        $category = ContactCategory::findOrFail($id);
        foreach ($category->items as $item) {
            if ($item->type === 'file') {
                Storage::disk('public')->delete($item->content);
            }
        }
        $category->delete();

        return back()->with('success', 'Category and its contacts deleted successfully.');
    }
}
