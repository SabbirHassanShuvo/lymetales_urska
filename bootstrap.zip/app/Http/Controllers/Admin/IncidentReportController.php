<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\IncidentReport;
use Illuminate\Http\Request;

class IncidentReportController extends Controller
{
    public function index()
    {
        $reports = IncidentReport::with('user')->latest()->get();
        return view('admin.incidents.index', compact('reports'));
    }

    public function show($id)
    {
        $report = IncidentReport::with('user')->findOrFail($id);
        return view('admin.incidents.show', compact('report'));
    }

    public function updateStatus(Request $request, $id)
    {
        $report = IncidentReport::findOrFail($id);
        $report->update(['status' => $request->status]);

        return back()->with('success', 'Status updated successfully.');
    }

    public function destroy($id)
    {
        IncidentReport::findOrFail($id)->delete();
        return redirect()->route('admin.incidents.index')->with('success', 'Report deleted successfully.');
    }
}
