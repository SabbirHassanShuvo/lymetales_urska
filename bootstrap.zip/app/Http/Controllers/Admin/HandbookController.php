<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Handbook;
use App\Models\HandbookChapter;
use App\Models\HandbookLesson;
use Illuminate\Http\Request;

class HandbookController extends Controller
{
    public function index()
    {
        $handbooks = Handbook::withCount(['chapters'])->get();
        return view('admin.handbooks.index', compact('handbooks'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        Handbook::create($request->all());

        return back()->with('success', 'Handbook created successfully.');
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $handbook = Handbook::findOrFail($id);
        $handbook->update($request->all());

        return back()->with('success', 'Handbook updated successfully.');
    }

    public function show($id)
    {
        $handbook = Handbook::with(['chapters.lessons'])->findOrFail($id);
        return view('admin.handbooks.show', compact('handbook'));
    }

    public function destroy($id)
    {
        $handbook = Handbook::findOrFail($id);
        $handbook->delete();

        return back()->with('success', 'Handbook deleted successfully.');
    }

    // Chapter Methods
    public function storeChapter(Request $request, $handbookId)
    {
        $request->validate([
            'title' => 'required|string|max:255',
        ]);

        HandbookChapter::create([
            'handbook_id' => $handbookId,
            'title' => $request->title,
            'order' => HandbookChapter::where('handbook_id', $handbookId)->count() + 1
        ]);

        return back()->with('success', 'Chapter added successfully.');
    }

    public function updateChapter(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
        ]);

        $chapter = HandbookChapter::findOrFail($id);
        $chapter->update(['title' => $request->title]);

        return back()->with('success', 'Chapter updated successfully.');
    }

    public function destroyChapter($id)
    {
        $chapter = HandbookChapter::findOrFail($id);
        $chapter->delete();

        return back()->with('success', 'Chapter deleted successfully.');
    }

    // Lesson Methods
    public function storeLesson(Request $request, $chapterId)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'type' => 'required|in:text,pdf',
            'content' => 'required_if:type,text',
            'file' => 'required_if:type,pdf|file|mimes:pdf|max:10240',
        ]);

        $filePath = null;
        if ($request->type === 'pdf' && $request->hasFile('file')) {
            $filePath = $request->file('file')->store('handbooks', 'public');
        }

        HandbookLesson::create([
            'handbook_chapter_id' => $chapterId,
            'title' => $request->title,
            'type' => $request->type,
            'content' => $request->type === 'text' ? $request->content : null,
            'file' => $filePath,
            'order' => HandbookLesson::where('handbook_chapter_id', $chapterId)->count() + 1
        ]);

        return back()->with('success', 'Lesson added successfully.');
    }

    public function editLesson($id)
    {
        $lesson = HandbookLesson::with('chapter.handbook')->findOrFail($id);
        return view('admin.handbooks.edit-lesson', compact('lesson'));
    }

    public function updateLesson(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'type' => 'required|in:text,pdf',
            'content' => 'required_if:type,text',
            'file' => 'nullable|file|mimes:pdf|max:10240',
        ]);

        $lesson = HandbookLesson::findOrFail($id);

        $data = [
            'title' => $request->title,
            'type' => $request->type,
            'content' => $request->type === 'text' ? $request->content : null,
        ];

        if ($request->type === 'pdf' && $request->hasFile('file')) {
            $data['file'] = $request->file('file')->store('handbooks', 'public');
        }

        $lesson->update($data);

        return redirect()->route('admin.handbooks.show', $lesson->chapter->handbook_id)
            ->with('success', 'Lesson updated successfully.');
    }

    public function destroyLesson($id)

    {
        $lesson = HandbookLesson::findOrFail($id);
        $lesson->delete();

        return back()->with('success', 'Lesson deleted successfully.');
    }

    public function uploadImage(Request $request)
    {
        $request->validate(['file' => 'required|image|max:5120']);
        $path = $request->file('file')->store('handbooks/images', 'public');
        return response()->json(['url' => asset('storage/' . $path)]);
    }
}
