<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\EmergencyCategory;
use App\Models\EmergencyItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class EmergencyController extends Controller
{
    public function index()
    {
        $categories = EmergencyCategory::withCount('items')->get();
        return view('admin.emergency.index', compact('categories'));
    }

    public function storeCategory(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'icon' => 'nullable|string',
        ]);

        EmergencyCategory::create($request->all());

        return back()->with('success', 'Emergency Category created successfully.');
    }

    public function updateCategory(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $category = EmergencyCategory::findOrFail($id);
        $category->update($request->all());

        return back()->with('success', 'Category updated successfully.');
    }

    public function show($id)
    {
        $category = EmergencyCategory::with('items')->findOrFail($id);
        return view('admin.emergency.show', compact('category'));
    }

    public function storeItem(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'type' => 'required|in:file,link,phone',
            'file' => 'nullable|mimes:pdf|max:10240',
            'link' => 'nullable|url',
            'phone' => 'nullable|string|max:20',
        ]);

        $category = EmergencyCategory::findOrFail($id);

        if ($request->type === 'file') {
            if (!$request->hasFile('file')) {
                return back()->withErrors(['file' => 'The PDF file is required when type is file.'])->withInput();
            }
            $path = $request->file('file')->store('emergency', 'public');
            $content = $path;
        } elseif ($request->type === 'link') {
            if (!$request->link) {
                return back()->withErrors(['link' => 'The link URL is required when type is link.'])->withInput();
            }
            $content = $request->link;
        } else {
            if (!$request->phone) {
                return back()->withErrors(['phone' => 'The phone number is required when type is phone.'])->withInput();
            }
            $content = $request->phone;
        }

        EmergencyItem::create([
            'emergency_category_id' => $category->id,
            'title' => $request->title,
            'type' => $request->type,
            'content' => $content,
        ]);

        return back()->with('success', 'Emergency item added successfully.');
    }

    public function updateItem(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'type' => 'required|in:file,link,phone',
            'file' => 'nullable|mimes:pdf|max:10240',
            'link' => 'nullable|url',
            'phone' => 'nullable|string|max:20',
        ]);

        $item = EmergencyItem::findOrFail($id);
        $content = $item->content;

        if ($request->type === 'file') {
            if ($request->hasFile('file')) {
                // Delete old file if exists
                if ($item->type === 'file') {
                    Storage::disk('public')->delete($item->content);
                }
                $content = $request->file('file')->store('emergency', 'public');
            } elseif ($item->type !== 'file') {
                return back()->withErrors(['file' => 'The PDF file is required when switching to file type.'])->withInput();
            }
        } elseif ($request->type === 'link') {
            if (!$request->link) {
                return back()->withErrors(['link' => 'The link URL is required when type is link.'])->withInput();
            }
            // Delete old file if switching from file
            if ($item->type === 'file') {
                Storage::disk('public')->delete($item->content);
            }
            $content = $request->link;
        } else {
            if (!$request->phone) {
                return back()->withErrors(['phone' => 'The phone number is required when type is phone.'])->withInput();
            }
            // Delete old file if switching from file
            if ($item->type === 'file') {
                Storage::disk('public')->delete($item->content);
            }
            $content = $request->phone;
        }

        $item->update([
            'title' => $request->title,
            'type' => $request->type,
            'content' => $content,
        ]);

        return back()->with('success', 'Emergency item updated successfully.');
    }

    public function destroyItem($id)
    {
        $item = EmergencyItem::findOrFail($id);
        if ($item->type === 'file') {
            Storage::disk('public')->delete($item->content);
        }
        $item->delete();

        return back()->with('success', 'Emergency item deleted successfully.');
    }

    public function destroyCategory($id)
    {
        $category = EmergencyCategory::findOrFail($id);
        foreach ($category->items as $item) {
            if ($item->type === 'file') {
                Storage::disk('public')->delete($item->content);
            }
        }
        $category->delete();

        return back()->with('success', 'Category and its items deleted successfully.');
    }
}
