<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\WorkplaceInspection;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class WorkplaceInspectionController extends Controller
{
    public function index()
    {
        $inspections = WorkplaceInspection::latest()->get();
        return view('admin.inspections.index', compact('inspections'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'type' => 'required|in:file,link',
            'file' => 'nullable|mimes:pdf|max:10240',
            'link' => 'nullable|url',
        ]);

        if ($request->type === 'file') {
            if (!$request->hasFile('file')) {
                return back()->withErrors(['file' => 'The PDF file is required when type is file.'])->withInput();
            }
            $path = $request->file('file')->store('inspections', 'public');
            $content = $path;
        } else {
            if (!$request->link) {
                return back()->withErrors(['link' => 'The link URL is required when type is link.'])->withInput();
            }
            $content = $request->link;
        }

        WorkplaceInspection::create([
            'title' => $request->title,
            'type' => $request->type,
            'content' => $content,
        ]);

        return back()->with('success', 'Workplace inspection added successfully.');
    }

    public function destroy($id)
    {
        $inspection = WorkplaceInspection::findOrFail($id);
        if ($inspection->type === 'file') {
            Storage::disk('public')->delete($inspection->content);
        }
        $inspection->delete();

        return back()->with('success', 'Workplace inspection deleted successfully.');
    }
}
