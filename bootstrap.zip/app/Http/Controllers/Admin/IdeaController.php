<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Idea;
use Illuminate\Http\Request;

class IdeaController extends Controller
{
    public function index()
    {
        $ideas = Idea::with('user')->latest()->get();
        return view('admin.ideas.index', compact('ideas'));
    }

    public function show($id)
    {
        $idea = Idea::with('user')->findOrFail($id);
        return view('admin.ideas.show', compact('idea'));
    }

    public function updateStatus(Request $request, $id)
    {
        $idea = Idea::findOrFail($id);
        $idea->update(['status' => $request->status]);

        return back()->with('success', 'Status updated successfully.');
    }

    public function destroy($id)
    {
        Idea::findOrFail($id)->delete();
        return back()->with('success', 'Idea deleted successfully.');
    }
}
