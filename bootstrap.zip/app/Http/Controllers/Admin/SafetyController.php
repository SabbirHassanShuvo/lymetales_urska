<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\SafetyCategory;
use App\Models\SafetyFile;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SafetyController extends Controller
{
    public function index()
    {
        $categories = SafetyCategory::withCount('files')->get();
        return view('admin.safety.index', compact('categories'));
    }

    public function storeCategory(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'icon' => 'nullable|string',
        ]);

        SafetyCategory::create($request->all());

        return back()->with('success', 'Category created successfully.');
    }

    public function updateCategory(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $category = SafetyCategory::findOrFail($id);
        $category->update($request->all());

        return back()->with('success', 'Category updated successfully.');
    }

    public function show($id)
    {
        $category = SafetyCategory::with('files')->findOrFail($id);
        return view('admin.safety.show', compact('category'));
    }

    public function storeFile(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'type' => 'required|in:file,link',
            'file' => 'nullable|mimes:pdf|max:10240',
            'link' => 'nullable|url',
        ]);

        $category = SafetyCategory::findOrFail($id);

        if ($request->type === 'file') {
            if (!$request->hasFile('file')) {
                return back()->withErrors(['file' => 'The PDF file is required when type is file.'])->withInput();
            }
            $path = $request->file('file')->store('safety_files', 'public');
            $content = $path;
        } else {
            if (!$request->link) {
                return back()->withErrors(['link' => 'The link URL is required when type is link.'])->withInput();
            }
            $content = $request->link;
        }

        SafetyFile::create([
            'safety_category_id' => $category->id,
            'title' => $request->title,
            'type' => $request->type,
            'content' => $content,
        ]);

        return back()->with('success', 'Safety item added successfully.');
    }

    public function destroyFile($id)
    {
        $file = SafetyFile::findOrFail($id);
        if ($file->type === 'file') {
            Storage::disk('public')->delete($file->content);
        }
        $file->delete();

        return back()->with('success', 'Safety item deleted successfully.');
    }

    public function destroyCategory($id)
    {
        $category = SafetyCategory::findOrFail($id);
        // Files are deleted via cascade in migration, but we should delete physical files too
        foreach ($category->files as $file) {
            if ($file->type === 'file') {
                Storage::disk('public')->delete($file->content);
            }
        }
        $category->delete();

        return back()->with('success', 'Category deleted successfully.');
    }
}
