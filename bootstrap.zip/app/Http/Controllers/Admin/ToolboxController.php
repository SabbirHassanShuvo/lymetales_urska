<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ToolboxCategory;
use App\Models\ToolboxItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ToolboxController extends Controller
{
    public function index()
    {
        $categories = ToolboxCategory::withCount('items')->get();
        return view('admin.toolboxes.index', compact('categories'));
    }

    public function storeCategory(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'icon' => 'nullable|string',
        ]);

        ToolboxCategory::create($request->all());

        return back()->with('success', 'Toolbox Category created successfully.');
    }

    public function updateCategory(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $category = ToolboxCategory::findOrFail($id);
        $category->update($request->all());

        return back()->with('success', 'Category updated successfully.');
    }

    public function show($id)
    {
        $category = ToolboxCategory::with('items')->findOrFail($id);
        return view('admin.toolboxes.show', compact('category'));
    }

    public function storeItem(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'type' => 'required|in:file,link',
            'file' => 'nullable|mimes:pdf|max:10240',
            'link' => 'nullable|url',
        ]);

        $category = ToolboxCategory::findOrFail($id);

        if ($request->type === 'file') {
            if (!$request->hasFile('file')) {
                return back()->withErrors(['file' => 'The PDF file is required when type is file.'])->withInput();
            }
            $path = $request->file('file')->store('toolboxes', 'public');
            $content = $path;
        } else {
            if (!$request->link) {
                return back()->withErrors(['link' => 'The link URL is required when type is link.'])->withInput();
            }
            $content = $request->link;
        }

        ToolboxItem::create([
            'toolbox_category_id' => $category->id,
            'title' => $request->title,
            'type' => $request->type,
            'content' => $content,
        ]);

        return back()->with('success', 'Toolbox item added successfully.');
    }

    public function destroyItem($id)
    {
        $item = ToolboxItem::findOrFail($id);
        if ($item->type === 'file') {
            Storage::disk('public')->delete($item->content);
        }
        $item->delete();

        return back()->with('success', 'Toolbox item deleted successfully.');
    }

    public function destroyCategory($id)
    {
        $category = ToolboxCategory::findOrFail($id);
        foreach ($category->items as $item) {
            if ($item->type === 'file') {
                Storage::disk('public')->delete($item->content);
            }
        }
        $category->delete();

        return back()->with('success', 'Category and its toolboxes deleted successfully.');
    }
}
