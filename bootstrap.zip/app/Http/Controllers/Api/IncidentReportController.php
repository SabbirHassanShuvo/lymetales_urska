<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\IncidentReport;
use Illuminate\Http\Request;

class IncidentReportController extends Controller
{
    public function index()
    {
        $userId = auth()->id();

        // Incidents
        $incidents = \App\Models\IncidentReport::where('user_id', $userId)
            ->latest()
            ->get()
            ->map(function ($r) {
                return [
                    'type' => 'incident',
                    'id' => $r->id,
                    'title' => $r->title,
                    'message' => $r->message,
                    'incident_date' => $r->incident_date->format('Y-m-d'),
                    'location' => $r->location,
                    'file_url' => $r->file ? asset('storage/' . $r->file) : null,
                    'status' => $r->status,
                    'submitted_at' => $r->created_at->format('Y-m-d H:i:s'),
                ];
            });

        // Ideas
        $ideas = \App\Models\Idea::where('user_id', $userId)
            ->latest()
            ->get()
            ->map(function ($r) {
                return [
                    'type' => 'idea',
                    'id' => $r->id,
                    'title' => $r->title,
                    'message' => $r->message,
                    'file_url' => $r->file ? asset('storage/' . $r->file) : null,
                    'status' => $r->status,
                    'submitted_at' => $r->created_at->format('Y-m-d H:i:s'),
                ];
            });

        // Complaints
        $complaints = \App\Models\Complaint::where('user_id', $userId)
            ->with('targetUser')
            ->latest()
            ->get()
            ->map(function ($r) {
                return [
                    'type' => 'complement',
                    'id' => $r->id,
                    'subject' => $r->subject,
                    'description' => $r->description,
                    'target_user' => $r->targetUser
                        ? $r->targetUser->first_name . ' ' . $r->targetUser->last_name
                        : null,
                    'target_user_id' => $r->target_user_id,
                    'status' => $r->status,
                    'submitted_at' => $r->created_at->format('Y-m-d H:i:s'),
                ];
            });

        // Merge and sort newest first
        $history = $incidents
            ->concat($ideas)
            ->concat($complaints)
            ->sortByDesc('submitted_at')
            ->values();

        return response()->json([
            'status' => 'success',
            'total' => $history->count(),
            'summary' => [
                'incidents' => $incidents->count(),
                'ideas' => $ideas->count(),
                'complaints' => $complaints->count(),
            ],
            'data' => $history,
        ]);
    }

    public function show(Request $request, $id)
    {
        $userId = auth()->id();
        $type   = $request->query('type', 'incident'); // default: incident

        switch ($type) {

            case 'idea':
                $record = \App\Models\Idea::where('user_id', $userId)->findOrFail($id);
                return response()->json([
                    'status' => 'success',
                    'data'   => [
                        'type'         => 'idea',
                        'id'           => $record->id,
                        'title'        => $record->title,
                        'message'      => $record->message,
                        'file_url'     => $record->file ? asset('storage/' . $record->file) : null,
                        'status'       => $record->status,
                        'submitted_at' => $record->created_at->format('Y-m-d H:i:s'),
                    ]
                ]);

            case 'complement':
                $record = \App\Models\Complaint::where('user_id', $userId)
                    ->with('targetUser')
                    ->findOrFail($id);
                return response()->json([
                    'status' => 'success',
                    'data'   => [
                        'type'           => 'complement',
                        'id'             => $record->id,
                        'subject'        => $record->subject,
                        'description'    => $record->description,
                        'target_user_id' => $record->target_user_id,
                        'target_user'    => $record->targetUser
                            ? $record->targetUser->first_name . ' ' . $record->targetUser->last_name
                            : null,
                        'target_email'   => $record->targetUser?->email,
                        'status'         => $record->status,
                        'submitted_at'   => $record->created_at->format('Y-m-d H:i:s'),
                    ]
                ]);

            default: // incident
                $record = \App\Models\IncidentReport::where('user_id', $userId)->findOrFail($id);
                return response()->json([
                    'status' => 'success',
                    'data'   => [
                        'type'          => 'incident',
                        'id'            => $record->id,
                        'title'         => $record->title,
                        'message'       => $record->message,
                        'incident_date' => $record->incident_date->format('Y-m-d'),
                        'location'      => $record->location,
                        'file_url'      => $record->file ? asset('storage/' . $record->file) : null,
                        'status'        => $record->status,
                        'submitted_by'  => auth()->user()->first_name . ' ' . auth()->user()->last_name,
                        'submitted_at'  => $record->created_at->format('Y-m-d H:i:s'),
                    ]
                ]);
        }
    }

    /**
     * Submit a new incident report
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'message' => 'required|string',
            'incident_date' => 'required|date',
            'location' => 'required|string|max:255',
            'file' => 'nullable|file|max:10240', // Max 10MB
        ]);

        $filePath = null;
        if ($request->hasFile('file')) {
            $filePath = $request->file('file')->store('incidents', 'public');
        }

        $report = IncidentReport::create([
            'user_id' => auth()->id(),
            'title' => $request->title,
            'message' => $request->message,
            'incident_date' => $request->incident_date,
            'location' => $request->location,
            'file' => $filePath,
            'status' => 'pending',
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Your incident report has been submitted successfully.',
            'data' => [
                'id' => $report->id,
                'title' => $report->title,
                'message' => $report->message,
                'incident_date' => $report->incident_date->format('Y-m-d'),
                'location' => $report->location,
                'file_url' => $report->file ? asset('storage/' . $report->file) : null,
                'status' => $report->status,
                'created_at' => $report->created_at->format('Y-m-d H:i:s'),
            ]
        ], 201);
    }
}
