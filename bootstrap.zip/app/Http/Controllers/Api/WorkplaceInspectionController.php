<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\WorkplaceInspection;
use Illuminate\Http\Request;

class WorkplaceInspectionController extends Controller
{
    public function index()
    {
        $inspections = WorkplaceInspection::latest()->get()->map(function ($item) {
            return [
                'id' => $item->id,
                'title' => $item->title,
                'type' => $item->type,
                'url' => $item->type === 'file' ? asset('storage/' . $item->content) : $item->content,
                'created_at' => $item->created_at->format('d M Y'),
            ];
        });

        return response()->json([
            'status' => 'success',
            'data' => $inspections
        ]);
    }
}
