<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Idea;
use Illuminate\Http\Request;

class IdeaController extends Controller
{
    /**
     * Submit a new idea
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|string|max:255',
            'message' => 'required|string',
            'file' => 'nullable|file|max:100240', // Max 10MB
        ]);

        $filePath = null;
        if ($request->hasFile('file')) {
            $filePath = $request->file('file')->store('ideas', 'public');
        }

        $idea = Idea::create([
            'user_id' => auth()->id(),
            'title' => $request->title,
            'message' => $request->message,
            'file' => $filePath,
            'status' => 'pending',
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Your idea has been submitted successfully.',
            'data' => [
                'id' => $idea->id,
                'title' => $idea->title,
                'message' => $idea->message,
                'file_url' => $idea->file ? asset('storage/' . $idea->file) : null,
                'status' => $idea->status,
                'created_at' => $idea->created_at->format('Y-m-d H:i:s'),
            ]
        ], 201);
    }
}
