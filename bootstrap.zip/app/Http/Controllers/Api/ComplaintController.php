<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Complaint;
use Illuminate\Http\Request;

class ComplaintController extends Controller
{
    /**
     * Submit a new complaint (complement)
     */
    public function store(Request $request)
    {
        $request->validate([
            'target_user_id' => 'required_without:name|nullable|exists:users,id',
            'name' => 'required_without:target_user_id|nullable|string|max:255',
            'subject' => 'required|string|max:255',
            'description' => 'required|string',
        ]);

        $complaint = Complaint::create([
            'user_id' => auth()->id(),
            'target_user_id' => $request->target_user_id,
            'name' => $request->name,
            'subject' => $request->subject,
            'description' => $request->description,
            'status' => 'pending',
        ]);

        return response()->json([
            'status' => 'success',
            'message' => 'Your complaint has been submitted successfully.',
            'data' => $complaint->load(['user', 'targetUser'])
        ], 201);
    }

    /**
     * Get all users in the database
     */
    public function usersWhoSubmitted()
    {
        $users = \App\Models\User::where('role', 'user')
            ->select('id', 'first_name', 'last_name', 'email', 'phone_number', 'status', 'photo', 'created_at')
            ->get()
            ->map(function ($user) {
                return [
                    'id' => $user->id,
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
                    'email' => $user->email,
                    'phone_number' => $user->phone_number,
                    'status' => $user->status,
                    'photo_url' => $user->photo ? asset('storage/' . $user->photo) : null,
                    'joined' => $user->created_at->format('Y-m-d'),
                ];
            });

        return response()->json([
            'status' => 'success',
            'total' => $users->count(),
            'data' => $users
        ]);
    }
}
