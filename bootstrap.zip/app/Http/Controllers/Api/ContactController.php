<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ContactCategory;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function index()
    {
        $categories = ContactCategory::with('items')->get()->map(function ($category) {
            return [
                'id' => $category->id,
                'name' => $category->name,
                'description' => $category->description,
                'icon' => $category->icon,
                'items' => $category->items->map(function ($item) {
                    return [
                        'id' => $item->id,
                        'title' => $item->title,
                        'type' => $item->type,
                        'url' => $item->type === 'file' ? asset('storage/' . $item->content) : $item->content,
                        'created_at' => $item->created_at->format('M Y'),
                    ];
                }),
            ];
        });

        return response()->json([
            'status' => 'success',
            'data' => $categories
        ]);
    }
}
