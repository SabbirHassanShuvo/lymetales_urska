<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Handbook;
use Illuminate\Http\Request;

class HandbookController extends Controller
{
    public function index()
    {
        $handbooks = Handbook::all();

        return response()->json([
            'status' => 'success',
            'data' => $handbooks
        ]);
    }

    public function show($id)
    {
        $handbook = Handbook::with(['chapters.lessons'])->findOrFail($id);

        return response()->json([
            'status' => 'success',
            'data' => [
                'id' => $handbook->id,
                'title' => $handbook->title,
                'description' => $handbook->description,
                'chapters' => $handbook->chapters->map(function ($chapter) {
                    return [
                        'id' => $chapter->id,
                        'title' => $chapter->title,
                        'lessons' => $chapter->lessons->map(function ($lesson) {
                            return [
                                'id' => $lesson->id,
                                'title' => $lesson->title,
                                'type' => $lesson->type,
                                'content' => $lesson->content,
                                'file_url' => $lesson->file ? asset('storage/' . $lesson->file) : null,
                            ];
                        })
                    ];
                })
            ]
        ]);
    }
}
