<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\SafetyCategory;
use Illuminate\Http\Request;

class SafetyController extends Controller
{
    public function index()
    {
        $categories = SafetyCategory::with('files')->get()->map(function ($category) {
            return [
                'id' => $category->id,
                'name' => $category->name,
                'description' => $category->description,
                'icon' => $category->icon,
                'files' => $category->files->map(function ($file) {
                    return [
                        'id' => $file->id,
                        'title' => $file->title,
                        'type' => $file->type,
                        'content' => $file->type === 'file' ? asset('storage/' . $file->content) : $file->content,
                        'created_at' => $file->created_at->format('d M, Y'),
                    ];
                }),
            ];
        });

        return response()->json([
            'status' => 'success',
            'data' => $categories
        ]);
    }
}
