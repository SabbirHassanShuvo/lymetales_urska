<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmergencyItem extends Model
{
    protected $fillable = ['emergency_category_id', 'title', 'type', 'content'];

    public function category()
    {
        return $this->belongsTo(EmergencyCategory::class, 'emergency_category_id');
    }
}
