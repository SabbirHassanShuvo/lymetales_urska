<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class IncidentReport extends Model
{
    protected $fillable = ['user_id', 'title', 'message', 'incident_date', 'file', 'location', 'status'];

    protected $casts = [
        'incident_date' => 'date',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
