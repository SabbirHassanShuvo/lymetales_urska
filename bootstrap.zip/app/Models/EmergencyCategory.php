<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmergencyCategory extends Model
{
    protected $fillable = ['name', 'description', 'icon'];

    public function items()
    {
        return $this->hasMany(EmergencyItem::class);
    }
}
