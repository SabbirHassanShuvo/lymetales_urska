<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ToolboxCategory extends Model
{
    protected $fillable = ['name', 'description', 'icon'];

    public function items()
    {
        return $this->hasMany(ToolboxItem::class);
    }
}
