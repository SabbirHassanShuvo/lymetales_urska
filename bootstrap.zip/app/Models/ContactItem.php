<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContactItem extends Model
{
    protected $fillable = ['contact_category_id', 'title', 'type', 'content'];

    public function category()
    {
        return $this->belongsTo(ContactCategory::class, 'contact_category_id');
    }
}
