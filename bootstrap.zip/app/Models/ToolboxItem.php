<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ToolboxItem extends Model
{
    protected $fillable = ['toolbox_category_id', 'title', 'type', 'content'];

    public function category()
    {
        return $this->belongsTo(ToolboxCategory::class, 'toolbox_category_id');
    }
}
