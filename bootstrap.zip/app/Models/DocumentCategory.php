<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DocumentCategory extends Model
{
    protected $fillable = ['name', 'description', 'icon'];

    public function items()
    {
        return $this->hasMany(DocumentItem::class);
    }
}
