<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class WorkplaceInspection extends Model
{
    protected $fillable = ['title', 'type', 'content'];
}
