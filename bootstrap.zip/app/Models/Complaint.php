<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Complaint extends Model
{
    protected $fillable = ['user_id', 'target_user_id', 'name', 'subject', 'description', 'status'];

    // User who submitted the complaint
    public function user()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    // User who is being complained about
    public function targetUser()
    {
        return $this->belongsTo(User::class, 'target_user_id');
    }
}
