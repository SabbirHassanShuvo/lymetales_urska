<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Handbook extends Model
{
    protected $fillable = ['title', 'description'];

    public function chapters()
    {
        return $this->hasMany(HandbookChapter::class)->orderBy('order');
    }
}
