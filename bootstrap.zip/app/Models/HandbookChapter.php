<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HandbookChapter extends Model
{
    protected $fillable = ['handbook_id', 'title', 'order'];

    public function handbook()
    {
        return $this->belongsTo(Handbook::class);
    }

    public function lessons()
    {
        return $this->hasMany(HandbookLesson::class)->orderBy('order');
    }
}
