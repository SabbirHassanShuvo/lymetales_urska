<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HandbookLesson extends Model
{
    protected $fillable = ['handbook_chapter_id', 'title', 'content', 'file', 'type', 'order'];

    public function chapter()
    {
        return $this->belongsTo(HandbookChapter::class, 'handbook_chapter_id');
    }
}
