<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SafetyFile extends Model
{
    protected $fillable = ['safety_category_id', 'title', 'type', 'content'];

    public function category()
    {
        return $this->belongsTo(SafetyCategory::class, 'safety_category_id');
    }
}
