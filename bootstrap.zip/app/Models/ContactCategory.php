<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContactCategory extends Model
{
    protected $fillable = ['name', 'description', 'icon'];

    public function items()
    {
        return $this->hasMany(ContactItem::class);
    }
}
