<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Idea extends Model
{
    protected $fillable = ['user_id', 'title', 'message', 'file', 'status'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
