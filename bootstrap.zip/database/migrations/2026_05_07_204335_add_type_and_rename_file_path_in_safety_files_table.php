<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('safety_files', function (Blueprint $table) {
            $table->string('type')->default('file')->after('title');
            $table->renameColumn('file_path', 'content');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('safety_files', function (Blueprint $table) {
            $table->dropColumn('type');
            $table->renameColumn('content', 'file_path');
        });
    }
};
