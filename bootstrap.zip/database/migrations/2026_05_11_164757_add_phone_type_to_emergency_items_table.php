<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('emergency_items', function (Blueprint $table) {
            $table->string('type')->change(); // Temporary change to string to allow enum update if needed, but in Laravel 10+ we can just change enum directly if doctrine/dbal is installed or using native schema.
        });
        
        // Actually, for enum changes, it's safer to just re-declare it if the DB supports it.
        // But for SQLite/MySQL, we might need a specific approach.
        // I'll try the direct approach first.
        Schema::table('emergency_items', function (Blueprint $table) {
            $table->enum('type', ['file', 'link', 'phone'])->change();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('emergency_items', function (Blueprint $table) {
            $table->enum('type', ['file', 'link'])->change();
        });
    }
};
