<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('toolbox_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('toolbox_category_id')->constrained()->onDelete('cascade');
            $table->string('title');
            $table->enum('type', ['file', 'link']);
            $table->text('content'); // File path or URL
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('toolbox_items');
    }
};
