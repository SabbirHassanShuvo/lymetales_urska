<?php

namespace Database\Seeders;

use App\Models\EmergencyCategory;
use Illuminate\Database\Seeder;

class EmergencySeeder extends Seeder
{
    public function run(): void
    {
        EmergencyCategory::create([
            'name' => 'First Aid',
            'description' => 'Standard procedures for emergency medical assistance',
            'icon' => 'medical',
        ]);

        EmergencyCategory::create([
            'name' => 'Evacuation Plans',
            'description' => 'Building and site evacuation maps and protocols',
            'icon' => 'exit',
        ]);
    }
}
