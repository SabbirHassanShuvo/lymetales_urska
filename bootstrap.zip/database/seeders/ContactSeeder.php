<?php

namespace Database\Seeders;

use App\Models\ContactCategory;
use Illuminate\Database\Seeder;

class ContactSeeder extends Seeder
{
    public function run(): void
    {
        ContactCategory::create([
            'name' => 'Contact List',
            'description' => 'The contact list is available as a PDF.',
            'icon' => 'phone',
        ]);
    }
}
