<?php

namespace Database\Seeders;

use App\Models\ToolboxCategory;
use Illuminate\Database\Seeder;

class ToolboxSeeder extends Seeder
{
    public function run(): void
    {
        ToolboxCategory::create([
            'name' => 'Monthly Toolboxes',
            'description' => 'Mandatory monthly safety reviews',
            'icon' => 'calendar',
        ]);

        ToolboxCategory::create([
            'name' => 'Specific Tasks',
            'description' => 'Toolboxes for specialized operations',
            'icon' => 'briefcase',
        ]);
    }
}
