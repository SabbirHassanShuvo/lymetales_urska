<?php

namespace Database\Seeders;

use App\Models\DocumentCategory;
use Illuminate\Database\Seeder;

class DocumentSeeder extends Seeder
{
    public function run(): void
    {
        DocumentCategory::create([
            'name' => 'Laws & Regulations',
            'description' => 'Version control 1x per month',
            'icon' => 'document-text',
        ]);

        DocumentCategory::create([
            'name' => 'DVP',
            'description' => 'Applications and helpdesk',
            'icon' => 'folder-open',
        ]);
    }
}
