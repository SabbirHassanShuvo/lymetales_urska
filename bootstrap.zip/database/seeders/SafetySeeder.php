<?php

namespace Database\Seeders;

use App\Models\SafetyCategory;
use Illuminate\Database\Seeder;

class SafetySeeder extends Seeder
{
    public function run(): void
    {
        SafetyCategory::create([
            'name' => 'Instructions',
            'description' => 'LMRA, PPE, Safe 5',
            'icon' => 'shield-check',
        ]);

        SafetyCategory::create([
            'name' => 'Manuals',
            'description' => 'Ciplans, ZKL, Fencing',
            'icon' => 'book-open',
        ]);
    }
}
