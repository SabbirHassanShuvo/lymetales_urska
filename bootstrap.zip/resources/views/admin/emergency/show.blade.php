@extends('layouts.admin')

@section('content')
<style>
    [x-cloak] { display: none !important; }
</style>
<div class="mb-8 flex items-center">
    <a href="{{ route('admin.emergency.index') }}" class="mr-4 p-2 bg-white border border-gray-100 rounded-xl text-gray-500 hover:text-indigo-600 hover:border-indigo-100 transition-all">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
    </a>
    <div>
        <h2 class="text-2xl font-bold text-gray-800">{{ $category->name }}</h2>
        <p class="text-sm text-gray-500">{{ $category->description }}</p>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <!-- Item List -->
    <div class="lg:col-span-2">
        <div class="bg-white rounded-2xl shadow-sm border border-gray-50 overflow-hidden">
            <div class="px-8 py-6 border-b border-gray-50">
                <h3 class="text-xl font-bold text-gray-800">{{ __('admin.items_files_links') }}</h3>
            </div>
            
            <div class="divide-y divide-gray-50">
                @forelse($category->items as $item)
                <div class="p-6 hover:bg-gray-50/50 transition-colors flex items-center justify-between">
                    <div class="flex items-center">
                        @if($item->type === 'file')
                        <div class="w-10 h-10 bg-red-50 text-red-600 rounded-lg flex items-center justify-center mr-4">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
                        </div>
                        @elseif($item->type === 'link')
                        <div class="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center mr-4">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.828a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                        </div>
                        @else
                        <div class="w-10 h-10 bg-green-50 text-green-600 rounded-lg flex items-center justify-center mr-4">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                        </div>
                        @endif
                        <div>
                            <h4 class="font-semibold text-gray-800">{{ $item->title }}</h4>
                            <p class="text-xs text-gray-400">
                                @if($item->type === 'file')
                                    {{ __('admin.pdf_file') }}
                                @elseif($item->type === 'link')
                                    {{ __('admin.external_link') }}
                                @else
                                    {{ __('admin.phone_number') }}
                                @endif
                                • {{ __('admin.items_added_on', ['date' => $item->created_at->format('M Y')]) }}
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-3">
                        @if($item->type === 'phone')
                            <a href="tel:{{ $item->content }}" class="px-3 py-1.5 bg-green-50 text-green-600 text-xs font-bold rounded-lg hover:bg-green-100 transition-colors">{{ __('admin.call_now') }}</a>
                        @else
                            <a href="{{ $item->type === 'file' ? asset('storage/' . $item->content) : $item->content }}" target="_blank" class="px-3 py-1.5 bg-gray-50 text-gray-600 text-xs font-bold rounded-lg hover:bg-gray-100 transition-colors">{{ __('admin.view') }}</a>
                        @endif
                        <button onclick="editItem(this)" 
                                data-id="{{ $item->id }}" 
                                data-title="{{ $item->title }}" 
                                data-type="{{ $item->type }}" 
                                data-content="{{ $item->content }}" 
                                class="p-2 text-gray-400 hover:text-indigo-600 transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                        </button>
                        <form action="{{ route('admin.emergency.item.destroy', $item->id) }}" method="POST" onsubmit="return confirm('{{ __('admin.delete_item_confirm') }}')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="p-2 text-gray-400 hover:text-red-600 transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </button>
                        </form>
                    </div>
                </div>
                @empty
                <div class="p-12 text-center text-gray-400 italic">{{ __('admin.no_records_found') }}</div>
                @endforelse
            </div>
        </div>
    </div>

    <!-- Add Item Form -->
    <div class="lg:col-span-1">
        @if($errors->any())
            <div class="mb-6 p-4 bg-red-50 text-red-700 rounded-xl border border-red-100">
                <ul class="list-disc list-inside text-sm">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="bg-white rounded-2xl shadow-sm border border-gray-50 p-8" x-data="{ type: '{{ old('type', 'file') }}' }">
            <h3 class="text-xl font-bold text-gray-800 mb-6">{{ __('admin.add_new_item') }}</h3>
            <form action="{{ route('admin.emergency.item.store', $category->id) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                @csrf
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.item_title') }}</label>
                    <input type="text" name="title" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200" placeholder="e.g. Evacuation Plan A">
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.item_type') }}</label>
                    <select name="type" x-model="type" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200">
                        <option value="file">{{ __('admin.pdf_upload') }}</option>
                        <option value="link">{{ __('admin.url_link') }}</option>
                        <option value="phone">{{ __('admin.phone_number') }}</option>
                    </select>
                </div>

                <div x-show="type === 'file'">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.pdf_file') }}</label>
                    <input type="file" name="file" accept="application/pdf" class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                </div>

                <div x-show="type === 'link'">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.url_link') }}</label>
                    <input type="url" name="link" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200" placeholder="https://emergency-portal.com">
                </div>
                
                <div x-show="type === 'phone'">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.phone_number') }}</label>
                    <input type="text" name="phone" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200" placeholder="+123456789">
                </div>

                <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 shadow-md shadow-indigo-100">
                    {{ __('admin.add_item') }}
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Edit Item Modal -->
<div x-data="{ 
    open: false, 
    type: 'file', 
    title: '', 
    action: '', 
    link: '', 
    phone: '',
    openModal(data) {
        this.open = true;
        this.type = data.type;
        this.title = data.title;
        this.action = `/admin/emergency/item/${data.id}`;
        if (data.type === 'link') this.link = data.content;
        if (data.type === 'phone') this.phone = data.content;
    },
    closeModal() {
        this.open = false;
    }
}" 
@open-edit-modal.window="openModal($event.detail)"
x-cloak
class="relative z-50">
    
    <div x-show="open" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0"
         x-transition:enter-end="opacity-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100"
         x-transition:leave-end="opacity-0"
         class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity"></div>

    <div x-show="open" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
         x-transition:enter-end="opacity-100 translate-y-0 sm:scale-100"
         x-transition:leave="transition ease-in duration-200"
         x-transition:leave-start="opacity-100 translate-y-0 sm:scale-100"
         x-transition:leave-end="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
         class="fixed inset-0 z-50 overflow-y-auto">
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen">&#8203;</span>
            <div @click.away="closeModal()" class="inline-block overflow-hidden text-left align-bottom transition-all transform bg-white rounded-2xl shadow-xl sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                <div class="px-8 py-6 border-b border-gray-50">
                    <h3 class="text-xl font-bold text-gray-800">{{ __('admin.edit_item') }}</h3>
                </div>
                <form :action="action" method="POST" enctype="multipart/form-data" class="p-8 space-y-6">
                    @csrf
                    @method('PUT')
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.item_title') }}</label>
                        <input type="text" name="title" x-model="title" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200">
                    </div>
                    <div>
                        <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.item_type') }}</label>
                        <select name="type" x-model="type" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200">
                            <option value="file">{{ __('admin.pdf_upload') }}</option>
                            <option value="link">{{ __('admin.url_link') }}</option>
                            <option value="phone">{{ __('admin.phone_number') }}</option>
                        </select>
                    </div>

                    <div x-show="type === 'file'">
                        <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.pdf_file') }} ({{ __('admin.leave_blank_keep_current') }})</label>
                        <input type="file" name="file" accept="application/pdf" class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                    </div>

                    <div x-show="type === 'link'">
                        <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.url_link') }}</label>
                        <input type="url" name="link" x-model="link" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200">
                    </div>
                    
                    <div x-show="type === 'phone'">
                        <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.phone_number') }}</label>
                        <input type="text" name="phone" x-model="phone" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200">
                    </div>

                    <div class="flex justify-end space-x-3">
                        <button type="button" @click="closeModal()" class="px-6 py-3 text-sm font-semibold text-gray-500 hover:bg-gray-50 rounded-xl transition-all duration-200">{{ __('admin.cancel') }}</button>
                        <button type="submit" class="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-semibold rounded-xl transition-all duration-200 shadow-md shadow-indigo-100">{{ __('admin.save_changes') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
    function editItem(button) {
        const id = button.getAttribute('data-id');
        const title = button.getAttribute('data-title');
        const type = button.getAttribute('data-type');
        const content = button.getAttribute('data-content');
        
        window.dispatchEvent(new CustomEvent('open-edit-modal', { 
            detail: { id, title, type, content } 
        }));
    }
</script>
@endpush

<!-- Simple Alpine.js for form toggling -->
<script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
@endsection
