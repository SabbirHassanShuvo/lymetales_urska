@extends('layouts.admin')

@section('content')
<div class="bg-white rounded-2xl shadow-sm border border-gray-50 overflow-hidden">
    <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center">
        <h3 class="text-xl font-bold text-gray-800">{{ __('admin.user_ideas') }}</h3>
    </div>
    
    <div class="overflow-x-auto">
        <table class="w-full text-left">
            <thead>
                <tr class="bg-gray-50 text-gray-500 text-xs font-bold uppercase tracking-wider">
                    <th class="px-8 py-4">{{ __('admin.user') }}</th>
                    <th class="px-8 py-4">{{ __('admin.idea_title') }}</th>
                    <th class="px-8 py-4">{{ __('admin.attachment') }}</th>
                    <th class="px-8 py-4">{{ __('admin.status') }}</th>
                    <th class="px-8 py-4">{{ __('admin.submitted') }}</th>
                    <th class="px-8 py-4 text-right">{{ __('admin.actions') }}</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                @forelse($ideas as $idea)
                <tr class="hover:bg-gray-50/50 transition-colors">
                    <td class="px-8 py-4">
                        <div class="font-semibold text-gray-800">{{ $idea->user->first_name }} {{ $idea->user->last_name }}</div>
                        <div class="text-xs text-gray-400">{{ $idea->user->email }}</div>
                    </td>
                    <td class="px-8 py-4">
                        <div class="font-medium text-gray-700">{{ $idea->title }}</div>
                        <div class="text-xs text-gray-500 truncate max-w-xs">{{ $idea->message }}</div>
                    </td>
                    <td class="px-8 py-4">
                        @if($idea->file)
                        <a href="{{ asset('storage/' . $idea->file) }}" target="_blank" class="inline-flex items-center text-xs font-semibold text-indigo-600 hover:text-indigo-800 transition-colors">
                            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"></path></svg>
                            {{ __('admin.view_file') }}
                        </a>
                        @else
                        <span class="text-xs text-gray-400 italic">{{ __('admin.no_attachment') }}</span>
                        @endif
                    </td>
                    <td class="px-8 py-4">
                        <span class="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase {{ 
                            $idea->status === 'pending' ? 'bg-yellow-100 text-yellow-700' : 
                            ($idea->status === 'reviewed' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700')
                        }}">
                            {{ __('admin.' . $idea->status) }}
                        </span>
                    </td>
                    <td class="px-8 py-4 text-xs text-gray-500">
                        {{ $idea->created_at->format('d M Y') }}
                    </td>
                    <td class="px-8 py-4 text-right">
                        <div class="flex items-center justify-end space-x-2">
                            <a href="{{ route('admin.ideas.show', $idea->id) }}" class="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors" title="{{ __('admin.view_details') }}">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                            </a>
                            <form action="{{ route('admin.ideas.status.update', $idea->id) }}" method="POST" class="inline-flex items-center">
                                @csrf
                                <select name="status" onchange="this.form.submit()" class="text-xs border-gray-200 rounded-lg focus:ring-indigo-100 focus:border-indigo-300">
                                    <option value="pending" {{ $idea->status === 'pending' ? 'selected' : '' }}>{{ __('admin.pending') }}</option>
                                    <option value="reviewed" {{ $idea->status === 'reviewed' ? 'selected' : '' }}>{{ __('admin.reviewed') }}</option>
                                    <option value="approved" {{ $idea->status === 'approved' ? 'selected' : '' }}>{{ __('admin.approved') }}</option>
                                </select>
                            </form>
                            <form action="{{ route('admin.ideas.destroy', $idea->id) }}" method="POST" onsubmit="return confirm('{{ __('admin.delete_idea_confirm') }}')">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="p-2 text-gray-400 hover:text-red-600 transition-colors">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                @empty
                <tr>
                    <td colspan="6" class="px-8 py-12 text-center text-gray-400 italic">{{ __('admin.no_records_found') }}</td>
                </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
