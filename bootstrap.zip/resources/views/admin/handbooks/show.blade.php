@extends('layouts.admin')

@section('content')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css">
<style>
    .note-editor.note-frame { border-radius: 12px; border: 1px solid #e5e7eb; }
    .note-toolbar { border-radius: 12px 12px 0 0 !important; background: #f9fafb !important; border-bottom: 1px solid #e5e7eb !important; }
    .note-editable { min-height: 350px; font-family: 'Inter', sans-serif; font-size: 15px; padding: 20px !important; }
    .note-statusbar { border-radius: 0 0 12px 12px; }

    /* Fix: Summernote dialogs must appear above our modal backdrop (z-60) */
    .note-modal { z-index: 99999 !important; }
    .note-modal-backdrop { z-index: 99998 !important; }
    .note-popover { z-index: 99999 !important; }
</style>
<div class="max-w-6xl mx-auto">
    <!-- Header -->
    <div class="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
            <a href="{{ route('admin.handbooks.index') }}" class="inline-flex items-center text-sm font-medium text-gray-500 hover:text-indigo-600 transition-colors mb-2">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                {{ __('admin.back_to_handbooks') }}
            </a>
            <h2 class="text-3xl font-bold text-gray-800">{{ $handbook->title }}</h2>
            <p class="text-gray-500 mt-1">{{ $handbook->description }}</p>
        </div>
        <button onclick="openChapterModal()" class="bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center justify-center">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
            {{ __('admin.add_chapter') }}
        </button>
    </div>

    <!-- Content -->
    <div class="space-y-6">
        @forelse($handbook->chapters as $chapter)
        <div class="bg-white rounded-2xl shadow-sm border border-gray-50 overflow-hidden">
            <div class="px-8 py-5 bg-gray-50/50 flex justify-between items-center border-b border-gray-100">
                <div class="flex items-center">
                    <span class="w-8 h-8 bg-indigo-600 text-white rounded-lg flex items-center justify-center font-bold text-sm mr-3">
                        {{ $loop->iteration }}
                    </span>
                    <h3 class="text-lg font-bold text-gray-800">{{ $chapter->title }}</h3>
                </div>
                <div class="flex items-center space-x-3">
                    <button onclick="editChapter({{ $chapter->id }}, '{{ addslashes($chapter->title) }}')" class="p-2 text-gray-400 hover:text-indigo-600 transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                    </button>
                    <button onclick="openLessonModal({{ $chapter->id }}, '{{ $chapter->title }}')" class="text-xs font-bold text-indigo-600 hover:text-indigo-700 uppercase tracking-widest bg-white px-3 py-1.5 rounded-lg border border-indigo-100 transition-all">
                        + {{ __('admin.add_lesson') }}
                    </button>
                    <form action="{{ route('admin.handbooks.chapter.destroy', $chapter->id) }}" method="POST" onsubmit="return confirm('{{ __('admin.delete_chapter_lessons_confirm') }}')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="text-gray-400 hover:text-red-600 transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="p-0">
                <table class="w-full text-left">
                    <tbody class="divide-y divide-gray-50">
                        @forelse($chapter->lessons as $lesson)
                        <tr class="group hover:bg-gray-50/30 transition-colors">
                            <td class="px-8 py-4 w-12 text-gray-300 font-medium">
                                {{ $loop->parent->iteration }}.{{ $loop->iteration }}
                            </td>
                            <td class="px-4 py-4">
                                <div class="font-bold text-gray-700">{{ $lesson->title }}</div>
                                <div class="flex items-center mt-1">
                                    @if($lesson->type === 'pdf')
                                        <span class="text-[10px] bg-red-100 text-red-700 px-1.5 py-0.5 rounded font-bold uppercase mr-2">PDF</span>
                                        <a href="{{ asset('storage/' . $lesson->file) }}" target="_blank" class="text-xs text-indigo-500 hover:underline">{{ __('admin.view_pdf_doc') }}</a>
                                    @else
                                        <span class="text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded font-bold uppercase mr-2">TEXT</span>
                                        <span class="text-xs text-gray-400">{{ __('admin.written_lesson_content') }}</span>
                                    @endif
                                </div>
                            </td>
                            <td class="px-8 py-4 text-right">
                                <div class="flex items-center justify-end space-x-1">
                                    <a href="{{ route('admin.handbooks.lesson.edit', $lesson->id) }}" class="p-2 text-indigo-500 hover:bg-indigo-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100">
                                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path></svg>
                                    </a>
                                    <form action="{{ route('admin.handbooks.lesson.destroy', $lesson->id) }}" method="POST" onsubmit="return confirm('{{ __('admin.delete_lesson_confirm') }}')">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="p-2 text-gray-400 hover:text-red-600 transition-colors opacity-0 group-hover:opacity-100">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        @empty
                        <tr>
                            <td colspan="3" class="px-8 py-6 text-center text-gray-400 text-sm italic">{{ __('admin.no_lessons_chapter') }}</td>
                        </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
        @empty
        <div class="py-20 text-center bg-white rounded-3xl border border-dashed border-gray-200">
            <div class="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                <svg class="w-10 h-10 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5S19.832 5.477 21 6.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
            </div>
            <p class="text-gray-400 font-medium italic">{{ __('admin.empty_book_desc') }}</p>
        </div>
        @endforelse
    </div>
</div>

<!-- Add Chapter Modal -->
<div id="chapterModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl">
        <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center">
            <h3 class="text-xl font-bold text-gray-800">{{ __('admin.add_chapter') }}</h3>
            <button onclick="closeChapterModal()" class="text-gray-400 hover:text-gray-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <form action="{{ route('admin.handbooks.chapter.store', $handbook->id) }}" method="POST" class="p-8">
            @csrf
            <div class="space-y-6">
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{{ __('admin.chapter_title') }}</label>
                    <input type="text" name="title" required placeholder="e.g. Fundamental Principles" class="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-100 transition-all">
                </div>
            </div>
            <div class="mt-8">
                <button type="submit" class="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
                    {{ __('admin.add_chapter') }}
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Chapter Modal -->
<div id="editChapterModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl">
        <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center">
            <h3 class="text-xl font-bold text-gray-800">{{ __('admin.edit_chapter') }}</h3>
            <button onclick="closeEditChapterModal()" class="text-gray-400 hover:text-gray-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <form id="editChapterForm" method="POST" class="p-8">
            @csrf
            @method('PUT')
            <div class="space-y-6">
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{{ __('admin.chapter_title') }}</label>
                    <input type="text" id="edit_chapter_title" name="title" required class="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-100 transition-all">
                </div>
            </div>
            <div class="mt-8">
                <button type="submit" class="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
                    {{ __('admin.update_chapter') }}
                </button>
            </div>
        </form>
    </div>
</div>


<!-- Add Lesson Modal -->
<div id="lessonModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-[60] flex items-center justify-center p-4 overflow-y-auto">
    <div class="bg-white rounded-3xl w-full max-w-4xl my-auto overflow-hidden shadow-2xl">
        <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center">
            <div>
                <h3 class="text-xl font-bold text-gray-800">{{ __('admin.add_lesson') }}</h3>
                <p class="text-xs text-gray-400 uppercase font-bold" id="chapterNameLabel"></p>
            </div>
            <button onclick="closeLessonModal()" class="text-gray-400 hover:text-gray-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <form id="lessonForm" method="POST" enctype="multipart/form-data" class="p-8">
            @csrf
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{{ __('admin.lesson_title') }}</label>
                    <input type="text" name="title" required placeholder="e.g. Quality Assurance 1.1" class="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-100 transition-all">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{{ __('admin.content_type') }}</label>
                    <select name="type" id="lessonType" onchange="toggleLessonContent()" class="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-100 transition-all">
                        <option value="text">{{ __('admin.written_content_editor') }}</option>
                        <option value="pdf">{{ __('admin.upload_pdf_doc') }}</option>
                    </select>
                </div>
            </div>

            <div id="textContent" class="space-y-4">
                <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{{ __('admin.lesson_content') }}</label>
                <textarea name="content" id="editor"></textarea>
            </div>

            <div id="pdfContent" class="hidden">
                <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{{ __('admin.pdf_file') }}</label>
                <div class="mt-2 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-200 border-dashed rounded-3xl hover:border-indigo-400 transition-colors">
                    <div class="space-y-1 text-center">
                        <svg class="mx-auto h-12 w-12 text-gray-300" stroke="currentColor" fill="none" viewBox="0 0 48 48"><path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" /></svg>
                        <div class="flex text-sm text-gray-600">
                            <label for="file-upload" class="relative cursor-pointer bg-white rounded-md font-bold text-indigo-600 hover:text-indigo-500">
                                <span>{{ __('admin.upload_a_file') }}</span>
                                <input id="file-upload" name="file" type="file" accept=".pdf" class="sr-only">
                            </label>
                            <p class="pl-1">{{ __('admin.drag_and_drop') }}</p>
                        </div>
                        <p class="text-xs text-gray-500">{{ __('admin.pdf_limit') }}</p>
                    </div>
                </div>
            </div>

            <div class="mt-8 flex justify-end">
                <button type="submit" class="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
                    {{ __('admin.save_lesson') }}
                </button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
<script>
    let summernoteReady = false;

    function openChapterModal() {
        document.getElementById('chapterModal').classList.remove('hidden');
    }

    function closeChapterModal() {
        document.getElementById('chapterModal').classList.add('hidden');
    }

    function editChapter(id, title) {
        const form = document.getElementById('editChapterForm');
        form.action = `/admin/handbooks/chapter/${id}`;
        document.getElementById('edit_chapter_title').value = title;
        document.getElementById('editChapterModal').classList.remove('hidden');
    }

    function closeEditChapterModal() {
        document.getElementById('editChapterModal').classList.add('hidden');
    }

    function openLessonModal(chapterId, chapterName) {
        document.getElementById('chapterNameLabel').textContent = "{{ __('admin.chapter_label', ['name' => '']) }}".replace(':name', chapterName);
        document.getElementById('lessonForm').action = '/admin/handbooks/chapter/' + chapterId + '/lesson';
        document.getElementById('lessonModal').classList.remove('hidden');

        // Init Summernote after modal is visible
        if (!summernoteReady) {
            $('#editor').summernote({
                height: 380,
                focus: true,
                dialogsInBody: true,
                dialogsFade: true,
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'underline', 'italic', 'strikethrough', 'superscript', 'subscript', 'clear']],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['height', ['height']],
                    ['table', ['table']],
                    ['insert', ['link', 'picture', 'video', 'hr']],
                    ['view', ['fullscreen', 'codeview', 'help']]
                ],
                styleTags: ['p', 'blockquote', 'pre', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
                fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Helvetica', 'Impact', 'Tahoma', 'Times New Roman', 'Verdana', 'Inter'],
                fontSizes: ['8', '9', '10', '11', '12', '14', '16', '18', '20', '22', '24', '28', '32', '36', '48', '64', '82', '150'],
                callbacks: {
                    onImageUpload: function(files) {
                        var formData = new FormData();
                        formData.append('file', files[0]);
                        formData.append('_token', '{{ csrf_token() }}');
                        $.ajax({
                            url: '/admin/handbooks/upload-image',
                            method: 'POST',
                            data: formData,
                            contentType: false,
                            processData: false,
                            success: function(data) {
                                $('#editor').summernote('insertImage', data.url);
                            }
                        });
                    }
                }
            });
            summernoteReady = true;
        }
    }

    function closeLessonModal() {
        document.getElementById('lessonModal').classList.add('hidden');
    }

    function toggleLessonContent() {
        const type = document.getElementById('lessonType').value;
        const textSection = document.getElementById('textContent');
        const pdfSection = document.getElementById('pdfContent');

        if (type === 'text') {
            textSection.classList.remove('hidden');
            pdfSection.classList.add('hidden');
        } else {
            textSection.classList.add('hidden');
            pdfSection.classList.remove('hidden');
        }
    }

    // Summernote syncs content to textarea automatically
    document.getElementById('lessonForm').addEventListener('submit', function() {
        // Summernote auto-syncs on submit, but do it explicitly
        var content = $('#editor').summernote('code');
        $('#editor').val(content);
    });
</script>
@endpush
@endsection
