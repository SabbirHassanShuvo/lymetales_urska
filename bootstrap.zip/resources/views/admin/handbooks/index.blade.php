@extends('layouts.admin')

@section('content')
<div class="flex justify-between items-center mb-8">
    <h2 class="text-2xl font-bold text-gray-800">{{ __('admin.kam_handbook') }}</h2>
    <button onclick="document.getElementById('addHandbookModal').classList.remove('hidden')" class="bg-indigo-600 text-white px-6 py-2.5 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center">
        <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
        {{ __('admin.add_new_handbook') }}
    </button>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
    @forelse($handbooks as $handbook)
    <div class="bg-white rounded-2xl shadow-sm border border-gray-50 overflow-hidden hover:shadow-md transition-shadow">
        <div class="p-6">
            <div class="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center mb-4">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5S19.832 5.477 21 6.253v13C19.832 18.477 18.246 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
            </div>
            <h3 class="text-lg font-bold text-gray-800 mb-2">{{ $handbook->title }}</h3>
            <p class="text-gray-500 text-sm mb-6 line-clamp-2">{{ $handbook->description ?? __('admin.no_records_found') }}</p>
            
            <div class="flex items-center justify-between pt-4 border-t border-gray-50">
                <span class="text-xs font-bold text-gray-400 uppercase tracking-wider">{{ __('admin.chapters_count', ['count' => $handbook->chapters_count]) }}</span>
                <div class="flex space-x-2">
                    <button onclick="editHandbook({{ $handbook->id }}, '{{ addslashes($handbook->title) }}', '{{ addslashes($handbook->description) }}')" class="p-2 text-gray-400 hover:text-indigo-600 transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                    </button>
                    <a href="{{ route('admin.handbooks.show', $handbook->id) }}" class="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                    </a>
                    <form action="{{ route('admin.handbooks.destroy', $handbook->id) }}" method="POST" onsubmit="return confirm('{{ __('admin.delete_handbook_confirm') }}')">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="p-2 text-gray-400 hover:text-red-600 transition-colors">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    @empty
    <div class="col-span-full py-12 text-center bg-white rounded-2xl border border-dashed border-gray-200">
        <p class="text-gray-400 italic">{{ __('admin.no_handbooks_desc') }}</p>
    </div>
    @endforelse
</div>

<!-- Add Handbook Modal -->
<div id="addHandbookModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl">
        <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center">
            <h3 class="text-xl font-bold text-gray-800">{{ __('admin.add_new_handbook') }}</h3>
            <button onclick="document.getElementById('addHandbookModal').classList.add('hidden')" class="text-gray-400 hover:text-gray-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <form action="{{ route('admin.handbooks.store') }}" method="POST" class="p-8">
            @csrf
            <div class="space-y-6">
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{{ __('admin.book_title') }}</label>
                    <input type="text" name="title" required placeholder="e.g. Quality Policy" class="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-100 transition-all">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{{ __('admin.short_description') }}</label>
                    <textarea name="description" rows="3" placeholder="Briefly describe what this handbook covers..." class="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-100 transition-all"></textarea>
                </div>
            </div>
            <div class="mt-8">
                <button type="submit" class="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
                    {{ __('admin.create_handbook') }}
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Handbook Modal -->
<div id="editHandbookModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl">
        <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center">
            <h3 class="text-xl font-bold text-gray-800">{{ __('admin.edit_handbook') }}</h3>
            <button onclick="document.getElementById('editHandbookModal').classList.add('hidden')" class="text-gray-400 hover:text-gray-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <form id="editHandbookForm" method="POST" class="p-8">
            @csrf
            @method('PUT')
            <div class="space-y-6">
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{{ __('admin.book_title') }}</label>
                    <input type="text" id="edit_handbook_title" name="title" required class="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-100 transition-all">
                </div>
                <div>
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">{{ __('admin.short_description') }}</label>
                    <textarea id="edit_handbook_description" name="description" rows="3" class="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-100 transition-all"></textarea>
                </div>
            </div>
            <div class="mt-8">
                <button type="submit" class="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100">
                    {{ __('admin.update_handbook') }}
                </button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
    function editHandbook(id, title, description) {
        const form = document.getElementById('editHandbookForm');
        form.action = `/admin/handbooks/${id}`;
        document.getElementById('edit_handbook_title').value = title;
        document.getElementById('edit_handbook_description').value = description;
        document.getElementById('editHandbookModal').classList.remove('hidden');
    }
</script>
@endpush
@endsection

