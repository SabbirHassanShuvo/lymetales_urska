@extends('layouts.admin')

@section('content')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.css">
<style>
    .note-editor.note-frame { border-radius: 12px; border: 1px solid #e5e7eb; }
    .note-toolbar { border-radius: 12px 12px 0 0 !important; background: #f9fafb !important; border-bottom: 1px solid #e5e7eb !important; }
    .note-editable { min-height: 450px; font-family: 'Inter', sans-serif; font-size: 15px; padding: 24px !important; line-height: 1.8; }
    .note-statusbar { border-radius: 0 0 12px 12px; }
    .note-modal { z-index: 99999 !important; }
    .note-modal-backdrop { z-index: 99998 !important; }
    .note-popover { z-index: 99999 !important; }
</style>

<div class="max-w-5xl mx-auto">
    <!-- Breadcrumb -->
    <div class="mb-6">
        <a href="{{ route('admin.handbooks.show', $lesson->chapter->handbook_id) }}" class="inline-flex items-center text-sm font-medium text-gray-500 hover:text-indigo-600 transition-colors">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            Back to {{ $lesson->chapter->handbook->title }}
        </a>
        <p class="text-xs text-gray-400 mt-1 uppercase tracking-widest font-bold">
            {{ $lesson->chapter->title }} &rsaquo; Editing Lesson
        </p>
    </div>

    <form action="{{ route('admin.handbooks.lesson.update', $lesson->id) }}" method="POST" enctype="multipart/form-data">
        @csrf
        @method('PUT')

        <div class="bg-white rounded-3xl shadow-sm border border-gray-50 overflow-hidden">
            <!-- Header -->
            <div class="px-8 py-6 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center">
                <div>
                    <h2 class="text-xl font-bold text-gray-800">Edit Lesson</h2>
                    <p class="text-sm text-gray-400 mt-0.5">Make changes and save when you're done.</p>
                </div>
                <button type="submit" class="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg shadow-indigo-100 flex items-center">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                    Save Changes
                </button>
            </div>

            <div class="p-8 space-y-8">
                <!-- Title & Type -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div>
                        <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Lesson Title</label>
                        <input type="text" name="title" value="{{ old('title', $lesson->title) }}" required
                            class="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-100 transition-all text-gray-800 font-medium">
                        @error('title')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-2">Content Type</label>
                        <select name="type" id="contentType" onchange="toggleContent()" class="w-full px-4 py-3 bg-gray-50 border-none rounded-xl focus:ring-2 focus:ring-indigo-100 transition-all">
                            <option value="text" {{ $lesson->type === 'text' ? 'selected' : '' }}>Written Content (Editor)</option>
                            <option value="pdf" {{ $lesson->type === 'pdf' ? 'selected' : '' }}>Upload PDF Document</option>
                        </select>
                    </div>
                </div>

                <!-- Text Editor -->
                <div id="textSection" class="{{ $lesson->type === 'pdf' ? 'hidden' : '' }}">
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">Lesson Content</label>
                    <textarea id="editor" name="content">{!! old('content', $lesson->content) !!}</textarea>
                    @error('content')<p class="text-red-500 text-xs mt-1">{{ $message }}</p>@enderror
                </div>

                <!-- PDF Upload -->
                <div id="pdfSection" class="{{ $lesson->type === 'text' ? 'hidden' : '' }}">
                    <label class="block text-xs font-bold text-gray-400 uppercase tracking-widest mb-3">PDF Document</label>

                    @if($lesson->file && $lesson->type === 'pdf')
                    <div class="mb-4 flex items-center p-4 bg-indigo-50 rounded-2xl border border-indigo-100">
                        <svg class="w-8 h-8 text-indigo-600 mr-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
                        <div class="flex-1">
                            <p class="text-sm font-bold text-indigo-800">Current PDF File</p>
                            <p class="text-xs text-indigo-500">Upload a new file below to replace it</p>
                        </div>
                        <a href="{{ asset('storage/' . $lesson->file) }}" target="_blank" class="text-xs font-bold text-indigo-600 hover:text-indigo-700 underline">View Current</a>
                    </div>
                    @endif

                    <div class="flex justify-center px-6 pt-5 pb-6 border-2 border-gray-200 border-dashed rounded-3xl hover:border-indigo-400 transition-colors cursor-pointer" onclick="document.getElementById('pdfInput').click()">
                        <div class="space-y-1 text-center">
                            <svg class="mx-auto h-12 w-12 text-gray-300" stroke="currentColor" fill="none" viewBox="0 0 48 48"><path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8m-12 4h.02" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                            <p class="text-sm text-gray-500"><span class="font-bold text-indigo-600">Click to upload</span> or drag and drop</p>
                            <p id="pdfFileName" class="text-xs text-gray-400">PDF up to 10MB</p>
                        </div>
                        <input id="pdfInput" name="file" type="file" accept=".pdf" class="sr-only" onchange="document.getElementById('pdfFileName').textContent = this.files[0].name">
                    </div>
                    @error('file')<p class="text-red-500 text-xs mt-2">{{ $message }}</p>@enderror
                </div>
            </div>
        </div>
    </form>
</div>

@push('scripts')
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>
<script>
    $(document).ready(function() {
        @if($lesson->type === 'text')
        $('#editor').summernote({
            height: 450,
            dialogsInBody: true,
            dialogsFade: true,
            toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'underline', 'italic', 'strikethrough', 'superscript', 'subscript', 'clear']],
                ['fontname', ['fontname']],
                ['fontsize', ['fontsize']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['height', ['height']],
                ['table', ['table']],
                ['insert', ['link', 'picture', 'video', 'hr']],
                ['view', ['fullscreen', 'codeview', 'help']]
            ],
            styleTags: ['p', 'blockquote', 'pre', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6'],
            fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New', 'Helvetica', 'Impact', 'Tahoma', 'Times New Roman', 'Verdana', 'Inter'],
            fontSizes: ['8', '9', '10', '11', '12', '14', '16', '18', '20', '22', '24', '28', '32', '36', '48', '64', '82', '150'],
            callbacks: {
                onImageUpload: function(files) {
                    var formData = new FormData();
                    formData.append('file', files[0]);
                    formData.append('_token', '{{ csrf_token() }}');
                    $.ajax({
                        url: '{{ route("admin.handbooks.upload-image") }}',
                        method: 'POST',
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function(data) {
                            $('#editor').summernote('insertImage', data.url);
                        }
                    });
                }
            }
        });
        @endif
    });

    function toggleContent() {
        const type = document.getElementById('contentType').value;
        document.getElementById('textSection').classList.toggle('hidden', type !== 'text');
        document.getElementById('pdfSection').classList.toggle('hidden', type !== 'pdf');
    }
</script>
@endpush
@endsection
