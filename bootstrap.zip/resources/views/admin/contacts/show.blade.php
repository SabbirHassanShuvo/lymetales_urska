@extends('layouts.admin')

@section('content')
<div class="mb-8 flex items-center">
    <a href="{{ route('admin.contacts.index') }}" class="mr-4 p-2 bg-white border border-gray-100 rounded-xl text-gray-500 hover:text-indigo-600 hover:border-indigo-100 transition-all">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
    </a>
    <div>
        <h2 class="text-2xl font-bold text-gray-800">{{ $category->name }}</h2>
        <p class="text-sm text-gray-500">{{ $category->description }}</p>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <!-- Item List -->
    <div class="lg:col-span-2">
        <div class="bg-white rounded-2xl shadow-sm border border-gray-50 overflow-hidden">
            <div class="px-8 py-6 border-b border-gray-50">
                <h3 class="text-xl font-bold text-gray-800">{{ __('admin.phone_numbers') }}</h3>
            </div>
            
            <div class="divide-y divide-gray-50">
                @forelse($category->items as $item)
                <div class="p-6 hover:bg-gray-50/50 transition-colors flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="w-10 h-10 bg-green-50 text-green-600 rounded-lg flex items-center justify-center mr-4">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-800">{{ $item->title }}</h4>
                            <p class="text-sm text-indigo-600 font-medium">{{ $item->content }}</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-2">
                        <a href="tel:{{ $item->content }}" class="px-3 py-1.5 bg-indigo-50 text-indigo-600 text-xs font-bold rounded-lg hover:bg-indigo-100 transition-colors">{{ __('admin.call_now') }}</a>
                        
                        <button onclick="editContact({{ $item->id }}, '{{ addslashes($item->title) }}', '{{ addslashes($item->content) }}')" 
                            class="p-2 text-gray-400 hover:text-indigo-600 transition-colors" title="{{ __('admin.edit_contact') }}">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                        </button>

                        <form action="{{ route('admin.contacts.item.destroy', $item->id) }}" method="POST" onsubmit="return confirm('{{ __('admin.delete_contact_confirm') }}')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="p-2 text-gray-400 hover:text-red-600 transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </button>
                        </form>
                    </div>
                </div>
                @empty
                <div class="p-12 text-center text-gray-400 italic">{{ __('admin.no_phone_numbers_desc') }}</div>
                @endforelse
            </div>
        </div>
    </div>

    <!-- Add Item Form -->
    <div class="lg:col-span-1">
        @if($errors->any())
            <div class="mb-6 p-4 bg-red-50 text-red-700 rounded-xl border border-red-100">
                <ul class="list-disc list-inside text-sm">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="bg-white rounded-2xl shadow-sm border border-gray-50 p-8">
            <h3 class="text-xl font-bold text-gray-800 mb-6">{{ __('admin.add_new_contact') }}</h3>
            <form action="{{ route('admin.contacts.item.store', $category->id) }}" method="POST" class="space-y-6">
                @csrf
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.contact_name') }}</label>
                    <input type="text" name="title" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200" placeholder="e.g. John Doe">
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.phone_number') }}</label>
                    <input type="text" name="phone" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200" placeholder="e.g. +1 234 567 890">
                </div>

                <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 shadow-md shadow-indigo-100">
                    {{ __('admin.add_contact') }}
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Edit Contact Modal -->
<div id="editContactModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl">
        <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center">
            <h3 class="text-xl font-bold text-gray-800">{{ __('admin.edit_contact') }}</h3>
            <button onclick="document.getElementById('editContactModal').classList.add('hidden')" class="text-gray-400 hover:text-gray-600">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
        </div>
        <form id="editContactForm" method="POST" class="p-8 space-y-6">
            @csrf
            @method('PUT')
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.contact_name') }}</label>
                <input type="text" id="edit_title" name="title" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200">
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.phone_number') }}</label>
                <input type="text" id="edit_phone" name="phone" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200">
            </div>
            <div class="pt-4">
                <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 shadow-md shadow-indigo-100">
                    {{ __('admin.update_contact') }}
                </button>
            </div>
        </form>
    </div>
</div>

@push('scripts')
<script>
    function editContact(id, title, phone) {
        const form = document.getElementById('editContactForm');
        form.action = `/admin/contacts/item/${id}`;
        document.getElementById('edit_title').value = title;
        document.getElementById('edit_phone').value = phone;
        document.getElementById('editContactModal').classList.remove('hidden');
    }
</script>
@endpush
@endsection
