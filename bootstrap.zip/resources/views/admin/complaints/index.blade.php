@extends('layouts.admin')

@section('content')
    <div class="bg-white rounded-2xl shadow-sm border border-gray-50 overflow-hidden">
        <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center">
            <div>
                <h3 class="text-xl font-bold text-gray-800">{{ __('admin.complaints') }}</h3>
                <p class="text-sm text-gray-400 mt-0.5">
                    {{ __('admin.total_complaints', ['count' => $complaints->count()]) }}</p>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left">
                <thead>
                    <tr class="bg-gray-50 text-gray-500 text-xs font-bold uppercase tracking-wider">
                        <th class="px-6 py-4">{{ __('admin.posted_by') }}</th>
                        <th class="px-6 py-4">{{ __('admin.complaint_about') }}</th>
                        <th class="px-6 py-4">{{ __('admin.subject_description') }}</th>
                        <th class="px-6 py-4">{{ __('admin.status') }}</th>
                        <th class="px-6 py-4">{{ __('admin.submitted') }}</th>
                        <th class="px-6 py-4 text-right">{{ __('admin.actions') }}</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-50">
                    @forelse($complaints as $complaint)
                                <tr class="hover:bg-gray-50/50 transition-colors">

                                    {{-- Posted By (who submitted) --}}
                                    <td class="px-6 py-4">
                                        <div class="flex items-center space-x-3">
                                            <div
                                                class="w-9 h-9 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 font-bold text-sm flex-shrink-0">
                                                {{ strtoupper(substr($complaint->user->first_name ?? '?', 0, 1)) }}
                                            </div>
                                            <div>
                                                <div class="font-semibold text-gray-800 text-sm">
                                                    {{ $complaint->user->first_name ?? __('admin.unknown') }}
                                                    {{ $complaint->user->last_name ?? '' }}
                                                </div>
                                                <div class="text-xs text-gray-400">{{ $complaint->user->email ?? '—' }}</div>
                                                <div class="text-[10px] text-gray-300 mt-0.5">ID #{{ $complaint->user_id }}</div>
                                            </div>
                                        </div>
                                    </td>

                                    {{-- Complaint About (target user) --}}
                                    <td class="px-6 py-4">
                                        @if($complaint->targetUser)
                                            <div class="flex items-center space-x-3">
                                                <div
                                                    class="w-9 h-9 rounded-full bg-red-100 flex items-center justify-center text-red-700 font-bold text-sm flex-shrink-0">
                                                    {{ strtoupper(substr($complaint->targetUser->first_name ?? '?', 0, 1)) }}
                                                </div>
                                                <div>
                                                    <div class="font-semibold text-gray-800 text-sm">
                                                        {{ $complaint->targetUser->first_name }} {{ $complaint->targetUser->last_name }}
                                                    </div>
                                                    <div class="text-xs text-gray-400">{{ $complaint->targetUser->email }}</div>
                                                    <div class="text-[10px] text-gray-300 mt-0.5">ID #{{ $complaint->target_user_id }}</div>
                                                </div>
                                            </div>
                                        @elseif($complaint->name)
                                            <div class="flex items-center space-x-3">
                                                <div
                                                    class="w-9 h-9 rounded-full bg-orange-100 flex items-center justify-center text-orange-700 font-bold text-sm flex-shrink-0">
                                                    {{ strtoupper(substr($complaint->name ?? '?', 0, 1)) }}
                                                </div>
                                                <div>
                                                    <div class="font-semibold text-gray-800 text-sm">
                                                        {{ $complaint->name }}
                                                    </div>
                                                    <div class="text-xs text-gray-400 italic">{{ __('admin.external_target') }}</div>
                                                </div>
                                            </div>
                                        @else
                                            <span class="text-xs text-gray-300 italic">{{ __('admin.not_specified') }}</span>
                                        @endif
                                    </td>

                                    {{-- Subject & Description --}}
                                    <td class="px-6 py-4 max-w-xs">
                                        <div class="font-medium text-gray-700 text-sm">{{ $complaint->subject }}</div>
                                        <div class="text-xs text-gray-400 mt-1 line-clamp-2">{{ $complaint->description }}</div>
                                    </td>

                                    {{-- Status --}}
                                    <td class="px-6 py-4">
                                        <span class="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase {{
                        $complaint->status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                        ($complaint->status === 'reviewed' ? 'bg-blue-100 text-blue-700' : 'bg-green-100 text-green-700')
                                        }}">
                                            {{ __('admin.' . $complaint->status) }}
                                        </span>
                                    </td>

                                    {{-- Date --}}
                                    <td class="px-6 py-4 text-xs text-gray-500 whitespace-nowrap">
                                        {{ $complaint->created_at->format('d M Y') }}<br>
                                        <span class="text-gray-300">{{ $complaint->created_at->format('H:i') }}</span>
                                    </td>

                                    {{-- Actions --}}
                                    <td class="px-6 py-4 text-right">
                                        <div class="flex items-center justify-end space-x-2">
                                            <a href="{{ route('admin.complaints.show', $complaint->id) }}"
                                                class="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                                                title="{{ __('admin.view_details') }}">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                        d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z">
                                                    </path>
                                                </svg>
                                            </a>
                                            <form action="{{ route('admin.complaints.status.update', $complaint->id) }}" method="POST"
                                                class="inline-flex items-center">
                                                @csrf
                                                <select name="status" onchange="this.form.submit()"
                                                    class="text-xs border-gray-200 rounded-lg focus:ring-indigo-100 focus:border-indigo-300">
                                                    <option value="pending" {{ $complaint->status === 'pending' ? 'selected' : '' }}>
                                                        {{ __('admin.pending') }}</option>
                                                    <option value="reviewed" {{ $complaint->status === 'reviewed' ? 'selected' : '' }}>
                                                        {{ __('admin.reviewed') }}</option>
                                                    <option value="resolved" {{ $complaint->status === 'resolved' ? 'selected' : '' }}>
                                                        {{ __('admin.resolved') }}</option>
                                                </select>
                                            </form>
                                            <form action="{{ route('admin.complaints.destroy', $complaint->id) }}" method="POST"
                                                onsubmit="return confirm('{{ __('admin.delete_complaint_confirm') }}')">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="p-2 text-gray-400 hover:text-red-600 transition-colors">
                                                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                            d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16">
                                                        </path>
                                                    </svg>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="px-8 py-12 text-center text-gray-400 italic">
                                {{ __('admin.no_records_found') }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@endsection