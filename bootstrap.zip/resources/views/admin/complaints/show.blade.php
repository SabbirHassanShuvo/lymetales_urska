@extends('layouts.admin')

@section('content')
<div class="max-w-4xl mx-auto">
    <div class="mb-6">
        <a href="{{ route('admin.complaints.index') }}" class="inline-flex items-center text-sm font-medium text-gray-500 hover:text-indigo-600 transition-colors">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            {{ __('admin.back_to_complaints') }}
        </a>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-50 overflow-hidden">
        <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center bg-gray-50/50">
            <div>
                <h3 class="text-xl font-bold text-gray-800">{{ $complaint->subject }}</h3>
                <p class="text-xs text-gray-500 uppercase tracking-widest font-bold mt-1">{{ __('admin.complaint_details') }}</p>
            </div>
            <form action="{{ route('admin.complaints.status.update', $complaint->id) }}" method="POST" class="flex items-center space-x-3">
                @csrf
                <select name="status" onchange="this.form.submit()" class="text-sm border-gray-200 rounded-xl focus:ring-indigo-100 focus:border-indigo-300">
                    <option value="pending" {{ $complaint->status === 'pending' ? 'selected' : '' }}>{{ __('admin.pending') }}</option>
                    <option value="reviewed" {{ $complaint->status === 'reviewed' ? 'selected' : '' }}>{{ __('admin.reviewed') }}</option>
                    <option value="resolved" {{ $complaint->status === 'resolved' ? 'selected' : '' }}>{{ __('admin.resolved') }}</option>
                </select>
            </form>
        </div>

        <div class="p-8 space-y-8">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Reporter Info -->
                <div class="space-y-4">
                    <h5 class="text-xs font-bold text-gray-400 uppercase tracking-widest">{{ __('admin.reporter_info') }}</h5>
                    <div class="flex items-start space-x-4 p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100">
                        <div class="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold flex-shrink-0">
                            {{ strtoupper(substr($complaint->user->first_name ?? '?', 0, 1)) }}
                        </div>
                        <div>
                            <h4 class="font-bold text-gray-800">{{ $complaint->user->first_name ?? __('admin.unknown') }} {{ $complaint->user->last_name ?? '' }}</h4>
                            <p class="text-sm text-gray-600">{{ $complaint->user->email ?? '—' }}</p>
                            <p class="text-xs text-indigo-400 mt-1 font-bold">{{ __('admin.user_id', ['id' => $complaint->user_id]) }}</p>
                        </div>
                    </div>
                </div>

                <!-- Target User Info -->
                <div class="space-y-4">
                    <h5 class="text-xs font-bold text-gray-400 uppercase tracking-widest">{{ __('admin.complaint_about') }}</h5>
                    @if($complaint->targetUser)
                    <div class="flex items-start space-x-4 p-4 bg-red-50/50 rounded-2xl border border-red-100">
                        <div class="w-12 h-12 bg-red-600 rounded-xl flex items-center justify-center text-white font-bold flex-shrink-0">
                            {{ strtoupper(substr($complaint->targetUser->first_name ?? '?', 0, 1)) }}
                        </div>
                        <div>
                            <h4 class="font-bold text-gray-800">{{ $complaint->targetUser->first_name }} {{ $complaint->targetUser->last_name }}</h4>
                            <p class="text-sm text-gray-600">{{ $complaint->targetUser->email }}</p>
                            <p class="text-xs text-red-400 mt-1 font-bold">{{ __('admin.user_id', ['id' => $complaint->target_user_id]) }}</p>
                        </div>
                    </div>
                    @elseif($complaint->name)
                    <div class="flex items-start space-x-4 p-4 bg-orange-50/50 rounded-2xl border border-orange-100">
                        <div class="w-12 h-12 bg-orange-600 rounded-xl flex items-center justify-center text-white font-bold flex-shrink-0">
                            {{ strtoupper(substr($complaint->name ?? '?', 0, 1)) }}
                        </div>
                        <div>
                            <h4 class="font-bold text-gray-800">{{ $complaint->name }}</h4>
                            <p class="text-sm text-orange-400 mt-1 font-bold">{{ __('admin.external_target') }}</p>
                        </div>
                    </div>
                    @else
                    <div class="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex items-center justify-center text-gray-400 italic text-sm h-[80px]">
                        {{ __('admin.general_complaint') }}
                    </div>
                    @endif
                </div>
            </div>

            <!-- Description -->
            <div>
                <h5 class="text-xs font-bold text-gray-400 uppercase mb-3">{{ __('admin.description') }}</h5>
                <div class="text-gray-700 leading-relaxed bg-gray-50 p-6 rounded-2xl border border-gray-100 whitespace-pre-wrap">
                    {{ $complaint->description }}
                </div>
            </div>

            <!-- Metadata -->
            <div class="pt-6 border-t border-gray-50 flex items-center justify-between text-xs text-gray-400">
                <span>{{ __('admin.submitted_on', ['date' => $complaint->created_at->format('d F Y'), 'time' => $complaint->created_at->format('H:i')]) }}</span>
                <span>{{ __('admin.entry_id', ['id' => $complaint->id]) }}</span>
            </div>
        </div>
    </div>
</div>
@endsection
