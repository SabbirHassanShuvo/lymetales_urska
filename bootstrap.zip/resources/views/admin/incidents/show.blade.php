@extends('layouts.admin')

@section('content')
<div class="max-w-4xl mx-auto">
    <div class="mb-6">
        <a href="{{ route('admin.incidents.index') }}" class="inline-flex items-center text-sm font-medium text-gray-500 hover:text-indigo-600 transition-colors">
            <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
            {{ __('admin.back_to_reports') }}
        </a>
    </div>

    <div class="bg-white rounded-2xl shadow-sm border border-gray-50 overflow-hidden">
        <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center bg-gray-50/50">
            <div>
                <h3 class="text-xl font-bold text-gray-800">{{ $report->title }}</h3>
                <p class="text-xs text-gray-500 uppercase tracking-widest font-bold mt-1">{{ __('admin.incident_details') }}</p>
            </div>
            <form action="{{ route('admin.incidents.status.update', $report->id) }}" method="POST" class="flex items-center space-x-3">
                @csrf
                <select name="status" onchange="this.form.submit()" class="text-sm border-gray-200 rounded-xl focus:ring-indigo-100 focus:border-indigo-300">
                    <option value="pending" {{ $report->status === 'pending' ? 'selected' : '' }}>{{ __('admin.pending') }}</option>
                    <option value="investigating" {{ $report->status === 'investigating' ? 'selected' : '' }}>{{ __('admin.investigating') }}</option>
                    <option value="closed" {{ $report->status === 'closed' ? 'selected' : '' }}>{{ __('admin.closed') }}</option>
                </select>
            </form>
        </div>

        <div class="p-8 space-y-8">
            <!-- User Info -->
            <div class="flex items-start space-x-4 p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100">
                <div class="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-bold">
                    {{ strtoupper(substr($report->user->first_name, 0, 1)) }}
                </div>
                <div>
                    <h4 class="font-bold text-gray-800">{{ $report->user->first_name }} {{ $report->user->last_name }}</h4>
                    <p class="text-sm text-gray-600">{{ $report->user->email }} • {{ $report->user->phone_number }}</p>
                </div>
            </div>

            <!-- Details Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                    <h5 class="text-xs font-bold text-gray-400 uppercase mb-2">{{ __('admin.incident_date') }}</h5>
                    <p class="text-gray-800 font-medium">{{ $report->incident_date->format('l, d F Y') }}</p>
                </div>
                <div>
                    <h5 class="text-xs font-bold text-gray-400 uppercase mb-2">{{ __('admin.location') }}</h5>
                    <p class="text-gray-800 font-medium">{{ $report->location }}</p>
                </div>
            </div>

            <!-- Message -->
            <div>
                <h5 class="text-xs font-bold text-gray-400 uppercase mb-2">{{ __('admin.description') }}</h5>
                <div class="text-gray-700 leading-relaxed bg-gray-50 p-6 rounded-2xl border border-gray-100 whitespace-pre-wrap">
                    {{ $report->message }}
                </div>
            </div>

            <!-- Attachment -->
            @if($report->file)
            <div>
                <h5 class="text-xs font-bold text-gray-400 uppercase mb-4">{{ __('admin.evidence_attachment') }}</h5>
                <div class="relative group inline-block">
                    @php
                        $extension = pathinfo($report->file, PATHINFO_EXTENSION);
                        $isImage = in_array(strtolower($extension), ['jpg', 'jpeg', 'png', 'gif', 'webp']);
                    @endphp

                    @if($isImage)
                        <img src="{{ asset('storage/' . $report->file) }}" class="max-w-full h-auto rounded-2xl shadow-lg border border-gray-100" style="max-height: 400px;">
                    @else
                        <div class="flex items-center p-4 bg-gray-50 rounded-xl border border-gray-100">
                            <svg class="w-8 h-8 text-indigo-600 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
                            <div>
                                <p class="text-sm font-bold text-gray-800">{{ __('admin.document_file') }}</p>
                                <p class="text-xs text-gray-500 uppercase">{{ __('admin.file_type', ['type' => strtoupper($extension)]) }}</p>
                            </div>
                        </div>
                    @endif
                    
                    <a href="{{ asset('storage/' . $report->file) }}" download class="mt-4 inline-flex items-center px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl transition-all shadow-md shadow-indigo-100">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                        {{ __('admin.download_original') }}
                    </a>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
@endsection
