@extends('layouts.admin')

@section('content')
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <!-- List -->
    <div class="lg:col-span-2">
        <div class="bg-white rounded-2xl shadow-sm border border-gray-50 overflow-hidden">
            <div class="px-8 py-6 border-b border-gray-50">
                <h3 class="text-xl font-bold text-gray-800">{{ __('admin.workplace_inspections') }}</h3>
            </div>
            
            <div class="divide-y divide-gray-50">
                @forelse($inspections as $item)
                <div class="p-6 hover:bg-gray-50/50 transition-colors flex items-center justify-between">
                    <div class="flex items-center">
                        @if($item->type === 'file')
                        <div class="w-10 h-10 bg-red-50 text-red-600 rounded-lg flex items-center justify-center mr-4">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
                        </div>
                        @else
                        <div class="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center mr-4">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.828a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                        </div>
                        @endif
                        <div>
                            <h4 class="font-semibold text-gray-800">{{ $item->title }}</h4>
                            <p class="text-xs text-gray-400">
                                {{ $item->type === 'file' ? __('admin.pdf_file') : __('admin.external_link') }} • {{ __('admin.added_on', ['date' => $item->created_at->format('d M Y')]) }}
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-3">
                        <a href="{{ $item->type === 'file' ? asset('storage/' . $item->content) : $item->content }}" target="_blank" class="px-3 py-1.5 bg-gray-50 text-gray-600 text-xs font-bold rounded-lg hover:bg-gray-100 transition-colors">{{ __('admin.view') }}</a>
                        <form action="{{ route('admin.inspections.destroy', $item->id) }}" method="POST" onsubmit="return confirm('{{ __('admin.delete_inspection_confirm') }}')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="p-2 text-gray-400 hover:text-red-600 transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </button>
                        </form>
                    </div>
                </div>
                @empty
                <div class="p-12 text-center text-gray-400 italic">{{ __('admin.no_records_found') }}</div>
                @endforelse
            </div>
        </div>
    </div>

    <!-- Add Form -->
    <div class="lg:col-span-1">
        @if($errors->any())
            <div class="mb-6 p-4 bg-red-50 text-red-700 rounded-xl border border-red-100">
                <ul class="list-disc list-inside text-sm">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="bg-white rounded-2xl shadow-sm border border-gray-50 p-8" x-data="{ type: '{{ old('type', 'file') }}' }">
            <h3 class="text-xl font-bold text-gray-800 mb-6">{{ __('admin.add_new_inspection') }}</h3>
            <form action="{{ route('admin.inspections.store') }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                @csrf
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.inspection_title') }}</label>
                    <input type="text" name="title" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200" placeholder="e.g. Monthly Site Audit">
                </div>
                
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.item_type') }}</label>
                    <select name="type" x-model="type" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200">
                        <option value="file">{{ __('admin.pdf_upload') }}</option>
                        <option value="link">{{ __('admin.url_link') }}</option>
                    </select>
                </div>

                <div x-show="type === 'file'">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.pdf_file') }}</label>
                    <input type="file" name="file" accept="application/pdf" class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                </div>

                <div x-show="type === 'link'">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.url_link') }}</label>
                    <input type="url" name="link" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200" placeholder="https://audit-portal.com">
                </div>

                <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 shadow-md shadow-indigo-100">
                    {{ __('admin.add_inspection') }}
                </button>
            </form>
        </div>
    </div>
</div>

<!-- Simple Alpine.js for form toggling -->
<script src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
@endsection
