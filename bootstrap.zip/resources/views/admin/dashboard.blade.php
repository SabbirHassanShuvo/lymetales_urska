@extends('layouts.admin')

@section('content')
<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
    <!-- Total Users -->
    <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-50 flex items-center">
        <div class="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center mr-4">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
        </div>
        <div>
            <p class="text-sm font-medium text-gray-500">{{ __('admin.total_users') }}</p>
            <p class="text-2xl font-bold text-gray-800">{{ $totalUsers }}</p>
        </div>
    </div>

    <!-- Approved Users -->
    <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-50 flex items-center">
        <div class="w-12 h-12 bg-green-50 text-green-600 rounded-xl flex items-center justify-center mr-4">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        </div>
        <div>
            <p class="text-sm font-medium text-gray-500">{{ __('admin.approved') }}</p>
            <p class="text-2xl font-bold text-gray-800">{{ $approvedUsers }}</p>
        </div>
    </div>

    <!-- Pending Requests -->
    <div class="bg-white p-6 rounded-2xl shadow-sm border border-gray-50 flex items-center">
        <div class="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center mr-4">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
        </div>
        <div>
            <p class="text-sm font-medium text-gray-500">{{ __('admin.pending_requests') }}</p>
            <p class="text-2xl font-bold text-gray-800">{{ $pendingUsers }}</p>
        </div>
    </div>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-gray-50 p-8">
    <h3 class="text-xl font-bold text-gray-800 mb-4">{{ __('admin.welcome_title') }}</h3>
    <p class="text-gray-500 leading-relaxed max-w-2xl">
        {{ __('admin.welcome_desc') }}
    </p>
</div>
@endsection
