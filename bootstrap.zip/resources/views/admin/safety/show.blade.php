@extends('layouts.admin')

@section('content')
<div class="mb-8 flex items-center">
    <a href="{{ route('admin.safety.index') }}" class="mr-4 p-2 bg-white border border-gray-100 rounded-xl text-gray-500 hover:text-indigo-600 hover:border-indigo-100 transition-all">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
    </a>
    <div>
        <h2 class="text-2xl font-bold text-gray-800">{{ $category->name }}</h2>
        <p class="text-sm text-gray-500">{{ $category->description }}</p>
    </div>
</div>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <!-- File List -->
    <div class="lg:col-span-2">
        <div class="bg-white rounded-2xl shadow-sm border border-gray-50 overflow-hidden">
            <div class="px-8 py-6 border-b border-gray-50 flex justify-between items-center">
                <h3 class="text-xl font-bold text-gray-800">{{ __('admin.safety_items') }}</h3>
            </div>
            
            <div class="divide-y divide-gray-50">
                @forelse($category->files as $file)
                <div class="p-6 hover:bg-gray-50/50 transition-colors flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="w-10 h-10 {{ $file->type === 'file' ? 'bg-red-50 text-red-600' : 'bg-blue-50 text-blue-600' }} rounded-lg flex items-center justify-center mr-4">
                            @if($file->type === 'file')
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"></path></svg>
                            @else
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                            @endif
                        </div>
                        <div>
                            <h4 class="font-semibold text-gray-800">{{ $file->title }}</h4>
                            <p class="text-xs text-gray-400">{{ __('admin.uploaded_on', ['date' => $file->created_at->format('d M, Y')]) }}</p>
                        </div>
                    </div>
                    <div class="flex items-center space-x-3">
                        @if($file->type === 'file')
                            <a href="{{ asset('storage/' . $file->content) }}" target="_blank" class="px-3 py-1.5 bg-gray-50 text-gray-600 text-xs font-bold rounded-lg hover:bg-gray-100 transition-colors">{{ __('admin.view_pdf') }}</a>
                        @else
                            <a href="{{ $file->content }}" target="_blank" class="px-3 py-1.5 bg-gray-50 text-gray-600 text-xs font-bold rounded-lg hover:bg-gray-100 transition-colors">{{ __('admin.view_link') }}</a>
                        @endif
                        <form action="{{ route('admin.safety.file.destroy', $file->id) }}" method="POST" onsubmit="return confirm('{{ __('admin.delete_file_confirm') }}')">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="p-2 text-gray-400 hover:text-red-600 transition-colors">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </button>
                        </form>
                    </div>
                </div>
                @empty
                <div class="p-12 text-center text-gray-400 italic">{{ __('admin.no_records_found') }}</div>
                @endforelse
            </div>
        </div>
    </div>

    <div class="lg:col-span-1">
        @if($errors->any())
            <div class="mb-6 p-4 bg-red-50 text-red-700 rounded-xl border border-red-100">
                <ul class="list-disc list-inside text-sm">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        <div class="bg-white rounded-2xl shadow-sm border border-gray-50 p-8" x-data="{ type: 'file' }">
            <h3 class="text-xl font-bold text-gray-800 mb-6">{{ __('admin.upload_safety_item') }}</h3>
            <form action="{{ route('admin.safety.file.store', $category->id) }}" method="POST" enctype="multipart/form-data" class="space-y-6">
                @csrf
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.file_title') }}</label>
                    <input type="text" name="title" required class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200" placeholder="e.g. ZKL usage">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.type') }}</label>
                    <select name="type" x-model="type" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200">
                        <option value="file">{{ __('admin.file') }}</option>
                        <option value="link">{{ __('admin.link') }}</option>
                    </select>
                </div>
                
                <div x-show="type === 'file'">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.pdf_file') }}</label>
                    <input type="file" name="file" accept="application/pdf" :required="type === 'file'" class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                </div>

                <div x-show="type === 'link'">
                    <label class="block text-sm font-semibold text-gray-700 mb-2">{{ __('admin.url_link') }}</label>
                    <input type="url" name="link" :required="type === 'link'" class="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-indigo-100 focus:border-indigo-400 outline-none transition-all duration-200" placeholder="https://example.com">
                </div>

                <button type="submit" class="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-3 px-6 rounded-xl transition-all duration-200 shadow-md shadow-indigo-100">
                    {{ __('admin.submit') }}
                </button>
            </form>
        </div>
    </div>
</div>
@endsection
