<?php

use App\Http\Controllers\Api\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::group([
    'middleware' => 'api',
    'prefix' => 'auth'
], function ($router) {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::post('/refresh', [AuthController::class, 'refresh']);
    Route::get('/user-profile', [AuthController::class, 'userProfile']);
    Route::post('/forgot-password', [AuthController::class, 'forgotPassword']);
    Route::post('/verify-otp', [AuthController::class, 'verifyOtp']);
    Route::post('/reset-password', [AuthController::class, 'resetPassword']);



});

Route::get('/safety', [\App\Http\Controllers\Api\SafetyController::class, 'index'])->middleware('api');
Route::get('/documents', [\App\Http\Controllers\Api\DocumentController::class, 'index'])->middleware('api');
Route::get('/toolboxes', [\App\Http\Controllers\Api\ToolboxController::class, 'index'])->middleware('api');
Route::get('/contacts', [\App\Http\Controllers\Api\ContactController::class, 'index'])->middleware('api');
Route::get('/emergency', [\App\Http\Controllers\Api\EmergencyController::class, 'index'])->middleware('api');
Route::get('/inspections', [\App\Http\Controllers\Api\WorkplaceInspectionController::class, 'index'])->middleware('api');
Route::get('/handbooks', [\App\Http\Controllers\Api\HandbookController::class, 'index'])->middleware('api');
Route::get('/handbooks/{id}', [\App\Http\Controllers\Api\HandbookController::class, 'show'])->middleware('api');


Route::middleware('auth:api')->group(function () {
    Route::post('/complaints', [\App\Http\Controllers\Api\ComplaintController::class, 'store']);
    Route::get('/complaints/users', [\App\Http\Controllers\Api\ComplaintController::class, 'usersWhoSubmitted']);
    Route::post('/ideas', [\App\Http\Controllers\Api\IdeaController::class, 'store']);
    Route::post('/incidents', [\App\Http\Controllers\Api\IncidentReportController::class, 'store']);
    Route::get('/incidents', [\App\Http\Controllers\Api\IncidentReportController::class, 'index']);
    Route::get('/incidents/{id}', [\App\Http\Controllers\Api\IncidentReportController::class, 'show']);

    // User Account Management
    Route::post('/change-password', [\App\Http\Controllers\Api\AuthController::class, 'changePassword']);
    Route::delete('/delete-account', [\App\Http\Controllers\Api\AuthController::class, 'deleteAccount']);
    Route::post('/update-profile', [\App\Http\Controllers\Api\AuthController::class, 'updateProfile']);
});
