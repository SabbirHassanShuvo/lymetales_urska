<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect()->route('admin.login');
});

Route::get('/lang/{locale}', function ($locale) {
    if (in_array($locale, ['en', 'nl'])) {
        session(['locale' => $locale]);
    }
    return back();
})->name('lang.switch');

// Admin Authentication Routes
Route::prefix('admin')->group(function () {
    Route::get('/login', [\App\Http\Controllers\Admin\AuthController::class, 'showLogin'])->name('admin.login');
    Route::post('/login', [\App\Http\Controllers\Admin\AuthController::class, 'login']);
    Route::post('/logout', [\App\Http\Controllers\Admin\AuthController::class, 'logout'])->name('admin.logout');

    // Protected Admin Routes
    Route::middleware(['auth', 'admin'])->group(function () {
        Route::get('/dashboard', [\App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('admin.dashboard');
        Route::get('/users-request', [\App\Http\Controllers\Admin\UserRequestController::class, 'index'])->name('admin.users.index');
        Route::post('/users-request/{id}/approve', [\App\Http\Controllers\Admin\UserRequestController::class, 'approve'])->name('admin.users.approve');
        Route::post('/users-request/{id}/reject', [\App\Http\Controllers\Admin\UserRequestController::class, 'reject'])->name('admin.users.reject');
        Route::put('/users-request/{id}', [\App\Http\Controllers\Admin\UserRequestController::class, 'update'])->name('admin.users.update');
        Route::delete('/users-request/{id}', [\App\Http\Controllers\Admin\UserRequestController::class, 'destroy'])->name('admin.users.destroy');

        // Safety Management
        Route::get('/safety', [\App\Http\Controllers\Admin\SafetyController::class, 'index'])->name('admin.safety.index');
        Route::post('/safety/category', [\App\Http\Controllers\Admin\SafetyController::class, 'storeCategory'])->name('admin.safety.category.store');
        Route::put('/safety/category/{id}', [\App\Http\Controllers\Admin\SafetyController::class, 'updateCategory'])->name('admin.safety.category.update');
        Route::delete('/safety/category/{id}', [\App\Http\Controllers\Admin\SafetyController::class, 'destroyCategory'])->name('admin.safety.category.destroy');
        Route::get('/safety/{id}', [\App\Http\Controllers\Admin\SafetyController::class, 'show'])->name('admin.safety.show');
        Route::post('/safety/{id}/file', [\App\Http\Controllers\Admin\SafetyController::class, 'storeFile'])->name('admin.safety.file.store');
        Route::delete('/safety/file/{id}', [\App\Http\Controllers\Admin\SafetyController::class, 'destroyFile'])->name('admin.safety.file.destroy');

        // Document Management
        Route::get('/documents', [\App\Http\Controllers\Admin\DocumentController::class, 'index'])->name('admin.documents.index');
        Route::post('/documents/category', [\App\Http\Controllers\Admin\DocumentController::class, 'storeCategory'])->name('admin.documents.category.store');
        Route::put('/documents/category/{id}', [\App\Http\Controllers\Admin\DocumentController::class, 'updateCategory'])->name('admin.documents.category.update');
        Route::delete('/documents/category/{id}', [\App\Http\Controllers\Admin\DocumentController::class, 'destroyCategory'])->name('admin.documents.category.destroy');
        Route::get('/documents/{id}', [\App\Http\Controllers\Admin\DocumentController::class, 'show'])->name('admin.documents.show');
        Route::post('/documents/{id}/item', [\App\Http\Controllers\Admin\DocumentController::class, 'storeItem'])->name('admin.documents.item.store');
        Route::delete('/documents/item/{id}', [\App\Http\Controllers\Admin\DocumentController::class, 'destroyItem'])->name('admin.documents.item.destroy');

        // Toolbox Management
        Route::get('/toolboxes', [\App\Http\Controllers\Admin\ToolboxController::class, 'index'])->name('admin.toolboxes.index');
        Route::post('/toolboxes/category', [\App\Http\Controllers\Admin\ToolboxController::class, 'storeCategory'])->name('admin.toolboxes.category.store');
        Route::put('/toolboxes/category/{id}', [\App\Http\Controllers\Admin\ToolboxController::class, 'updateCategory'])->name('admin.toolboxes.category.update');
        Route::delete('/toolboxes/category/{id}', [\App\Http\Controllers\Admin\ToolboxController::class, 'destroyCategory'])->name('admin.toolboxes.category.destroy');
        Route::get('/toolboxes/{id}', [\App\Http\Controllers\Admin\ToolboxController::class, 'show'])->name('admin.toolboxes.show');
        Route::post('/toolboxes/{id}/item', [\App\Http\Controllers\Admin\ToolboxController::class, 'storeItem'])->name('admin.toolboxes.item.store');
        Route::delete('/toolboxes/item/{id}', [\App\Http\Controllers\Admin\ToolboxController::class, 'destroyItem'])->name('admin.toolboxes.item.destroy');

        // Contact Management
        Route::get('/contacts', [\App\Http\Controllers\Admin\ContactController::class, 'index'])->name('admin.contacts.index');
        Route::post('/contacts/category', [\App\Http\Controllers\Admin\ContactController::class, 'storeCategory'])->name('admin.contacts.category.store');
        Route::put('/contacts/category/{id}', [\App\Http\Controllers\Admin\ContactController::class, 'updateCategory'])->name('admin.contacts.category.update');
        Route::delete('/contacts/category/{id}', [\App\Http\Controllers\Admin\ContactController::class, 'destroyCategory'])->name('admin.contacts.category.destroy');
        Route::get('/contacts/{id}', [\App\Http\Controllers\Admin\ContactController::class, 'show'])->name('admin.contacts.show');
        Route::post('/contacts/{id}/item', [\App\Http\Controllers\Admin\ContactController::class, 'storeItem'])->name('admin.contacts.item.store');
        Route::put('/contacts/item/{id}', [\App\Http\Controllers\Admin\ContactController::class, 'updateItem'])->name('admin.contacts.item.update');
        Route::delete('/contacts/item/{id}', [\App\Http\Controllers\Admin\ContactController::class, 'destroyItem'])->name('admin.contacts.item.destroy');

        // Emergency Management
        Route::get('/emergency', [\App\Http\Controllers\Admin\EmergencyController::class, 'index'])->name('admin.emergency.index');
        Route::post('/emergency/category', [\App\Http\Controllers\Admin\EmergencyController::class, 'storeCategory'])->name('admin.emergency.category.store');
        Route::put('/emergency/category/{id}', [\App\Http\Controllers\Admin\EmergencyController::class, 'updateCategory'])->name('admin.emergency.category.update');
        Route::delete('/emergency/category/{id}', [\App\Http\Controllers\Admin\EmergencyController::class, 'destroyCategory'])->name('admin.emergency.category.destroy');
        Route::get('/emergency/{id}', [\App\Http\Controllers\Admin\EmergencyController::class, 'show'])->name('admin.emergency.show');
        Route::post('/emergency/{id}/item', [\App\Http\Controllers\Admin\EmergencyController::class, 'storeItem'])->name('admin.emergency.item.store');
        Route::put('/emergency/item/{id}', [\App\Http\Controllers\Admin\EmergencyController::class, 'updateItem'])->name('admin.emergency.item.update');
        Route::delete('/emergency/item/{id}', [\App\Http\Controllers\Admin\EmergencyController::class, 'destroyItem'])->name('admin.emergency.item.destroy');

        // Workplace Inspections
        Route::get('/inspections', [\App\Http\Controllers\Admin\WorkplaceInspectionController::class, 'index'])->name('admin.inspections.index');
        Route::post('/inspections', [\App\Http\Controllers\Admin\WorkplaceInspectionController::class, 'store'])->name('admin.inspections.store');
        Route::delete('/inspections/{id}', [\App\Http\Controllers\Admin\WorkplaceInspectionController::class, 'destroy'])->name('admin.inspections.destroy');

        // Complements (Complaints)
        Route::get('/complaints', [\App\Http\Controllers\Admin\ComplaintController::class, 'index'])->name('admin.complaints.index');
        Route::get('/complaints/{id}', [\App\Http\Controllers\Admin\ComplaintController::class, 'show'])->name('admin.complaints.show');
        Route::post('/complaints/{id}/status', [\App\Http\Controllers\Admin\ComplaintController::class, 'updateStatus'])->name('admin.complaints.status.update');
        Route::delete('/complaints/{id}', [\App\Http\Controllers\Admin\ComplaintController::class, 'destroy'])->name('admin.complaints.destroy');

        // Ideas Management
        Route::get('/ideas', [\App\Http\Controllers\Admin\IdeaController::class, 'index'])->name('admin.ideas.index');
        Route::get('/ideas/{id}', [\App\Http\Controllers\Admin\IdeaController::class, 'show'])->name('admin.ideas.show');
        Route::post('/ideas/{id}/status', [\App\Http\Controllers\Admin\IdeaController::class, 'updateStatus'])->name('admin.ideas.status.update');
        Route::delete('/ideas/{id}', [\App\Http\Controllers\Admin\IdeaController::class, 'destroy'])->name('admin.ideas.destroy');

        // Incident Reports
        Route::get('/incidents', [\App\Http\Controllers\Admin\IncidentReportController::class, 'index'])->name('admin.incidents.index');
        Route::get('/incidents/{id}', [\App\Http\Controllers\Admin\IncidentReportController::class, 'show'])->name('admin.incidents.show');
        Route::post('/incidents/{id}/status', [\App\Http\Controllers\Admin\IncidentReportController::class, 'updateStatus'])->name('admin.incidents.status.update');
        Route::delete('/incidents/{id}', [\App\Http\Controllers\Admin\IncidentReportController::class, 'destroy'])->name('admin.incidents.destroy');

        // KAM Handbook Management
        Route::get('/handbooks', [\App\Http\Controllers\Admin\HandbookController::class, 'index'])->name('admin.handbooks.index');
        Route::post('/handbooks', [\App\Http\Controllers\Admin\HandbookController::class, 'store'])->name('admin.handbooks.store');
        Route::put('/handbooks/{id}', [\App\Http\Controllers\Admin\HandbookController::class, 'update'])->name('admin.handbooks.update');
        Route::get('/handbooks/{id}', [\App\Http\Controllers\Admin\HandbookController::class, 'show'])->name('admin.handbooks.show');
        Route::delete('/handbooks/{id}', [\App\Http\Controllers\Admin\HandbookController::class, 'destroy'])->name('admin.handbooks.destroy');
        
        Route::post('/handbooks/{id}/chapter', [\App\Http\Controllers\Admin\HandbookController::class, 'storeChapter'])->name('admin.handbooks.chapter.store');
        Route::put('/handbooks/chapter/{id}', [\App\Http\Controllers\Admin\HandbookController::class, 'updateChapter'])->name('admin.handbooks.chapter.update');
        Route::delete('/handbooks/chapter/{id}', [\App\Http\Controllers\Admin\HandbookController::class, 'destroyChapter'])->name('admin.handbooks.chapter.destroy');
        
        Route::post('/handbooks/chapter/{id}/lesson', [\App\Http\Controllers\Admin\HandbookController::class, 'storeLesson'])->name('admin.handbooks.lesson.store');
        Route::get('/handbooks/lesson/{id}/edit', [\App\Http\Controllers\Admin\HandbookController::class, 'editLesson'])->name('admin.handbooks.lesson.edit');
        Route::put('/handbooks/lesson/{id}', [\App\Http\Controllers\Admin\HandbookController::class, 'updateLesson'])->name('admin.handbooks.lesson.update');
        Route::delete('/handbooks/lesson/{id}', [\App\Http\Controllers\Admin\HandbookController::class, 'destroyLesson'])->name('admin.handbooks.lesson.destroy');
        Route::post('/handbooks/upload-image', [\App\Http\Controllers\Admin\HandbookController::class, 'uploadImage'])->name('admin.handbooks.upload-image');
    });
});
